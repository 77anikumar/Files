/**
 *	Yahtzee.java
 *	Two players roll dice and decide scoring categories while trying to
 * 	fill up these categories and score the highest point total.
 *
 *	@author	Ani Kumar
 *	@since	October 23, 2024
 */
public class Yahtzee {
	Dice dice;
	DiceGroup dicegroup;
	
	public Yahtzee() {
		dice = new Dice();
		dicegroup = new DiceGroup();
	}
	
	public static void main(String[] args) {
		Yahtzee yt = new Yahtzee();
		yt.runner();
	}
	
	public void runner() {
		printHeader();
		chooseNamesAndFirst();
	}
		
	public void printHeader() {
		System.out.println("\n");
		System.out.println("+------------------------------------------------------------------------------------+");
		System.out.println("| WELCOME TO MONTA VISTA YAHTZEE!                                                    |");
		System.out.println("|                                                                                    |");
		System.out.println("| There are 13 rounds in a game of Yahtzee. In each turn, a player can roll his/her  |");
		System.out.println("| dice up to 3 times in order to get the desired combination. On the first roll, the |");
		System.out.println("| player rolls all five of the dice at once. On the second and third rolls, the      |");
		System.out.println("| player can roll any number of dice he/she wants to, including none or all of them, |");
		System.out.println("| trying to get a good combination.                                                  |");
		System.out.println("| The player can choose whether he/she wants to roll once, twice or three times in   |");
		System.out.println("| each turn. After the three rolls in a turn, the player must put his/her score down |");
		System.out.println("| on the scorecard, under any one of the thirteen categories. The score that the     |");
		System.out.println("| player finally gets for that turn depends on the category/box that he/she chooses  |");
		System.out.println("| and the combination that he/she got by rolling the dice. But once a box is chosen  |");
		System.out.println("| on the score card, it can't be chosen again.                                       |");
		System.out.println("|                                                                                    |");
		System.out.println("| LET'S PLAY SOME YAHTZEE!                                                           |");
		System.out.println("+------------------------------------------------------------------------------------+");
		System.out.println("\n\n");
	}
	
	public void chooseNamesAndFirst() {
		boolean askOneAgain, askTwoAgain, redo;
		String p1Name, p2Name, name;
		p1Name = p2Name = name = "";
		askOneAgain = askTwoAgain = redo = true;
		while (askOneAgain) {
			p1Name = Prompt.getString("Player 1, please enter your first name");
			if (p1Name.length() != 0)
				askOneAgain = false;
		}
		System.out.println();
		while (askTwoAgain) {
			p2Name = Prompt.getString("Player 2, please enter your first name");
			if (p2Name.length() != 0)
				askTwoAgain = false;
		}
		while (redo) {
			Prompt.getString("\nLet's see who will go first. " + p1Name +
								", please hit enter to roll the dice");
			dicegroup.rollDice();
			dicegroup.printDice();
			int p1Sum = dicegroup.getTotal();
			
			Prompt.getString(p2Name + ", it's your turn. Please hit enter to roll the dice");
			dicegroup.rollDice();
			dicegroup.printDice();
			int p2Sum = dicegroup.getTotal();
			
			System.out.println(p1Name+", you rolled a sum of "+p1Sum+", and "
								+p2Name+", you rolled a sum of "+p2Sum+".");
			if (p1Sum != p2Sum) {
				if (p1Sum > p2Sum)
				name = p1Name;
				else if (p2Sum > p1Sum)
					name = p2Name;
				redo = false;
			} else
				System.out.println("\nYou both rolled the same sum! Try again.");
		}
		System.out.print(name+", since your sum was higher, you'll roll first.");
	}
}
