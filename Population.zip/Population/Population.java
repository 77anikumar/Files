import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
/**
 *	Population - implements different sorting methods and organizes a large set of data
 *	of over 30,000 USA cities and their populations.
 *	Requires FileUtils and Prompt classes.
 *
 *	@author	Ani Kumar
 *	@since	December 10, 2024
 */
public class Population {
	private List<City> cities; 								// list of cities
	private final String DATA_FILE = "usPopData2017.txt";	// US data file

	/* Constructor that initializes fields */
	public Population() {
		cities = new ArrayList<>();
	}

	/* Main that executes program */
	public static void main(String[] args) {
		Population population = new Population();
		population.runner();
	}

	/* Runner that calls other methods in order */
	public void runner() {
		loadCities();
		printIntroduction();
		getInput();
	}

	/* Reads text file, parses each line into City objects, and adds to List cities */
	public void loadCities() {
		try (Scanner scanner = FileUtils.openToRead(DATA_FILE)) {
			scanner.useDelimiter("[\t\n]");
			while (scanner.hasNext()) {
				String state = scanner.next();
				String name = scanner.next();
				String designation = scanner.next();
				int population = scanner.nextInt();
				cities.add(new City(state, name, designation, population));
			}
		} catch (Exception e) {
			System.err.println("Error loading file: " + e.getMessage());
		}
	}

	/**	Prints the introduction to Population */
	public void printIntroduction() {
		System.out.println("   ___                  _       _   _");
		System.out.println("  / _ \\___  _ __  _   _| | __ _| |_(_) ___  _ __ ");
		System.out.println(" / /_)/ _ \\| '_ \\| | | | |/ _` | __| |/ _ \\| '_ \\ ");
		System.out.println("/ ___/ (_) | |_) | |_| | | (_| | |_| | (_) | | | |");
		System.out.println("\\/    \\___/| .__/ \\__,_|_|\\__,_|\\__|_|\\___/|_| |_|");
		System.out.println("           |_|");
		System.out.println("\n31765 cities in database\n");
	}

	/** Print out the choices for population sorting */
	public void printMenu() {
		System.out.println("1. Fifty least populous cities in USA (Selection Sort)");
		System.out.println("2. Fifty most populous cities in USA (Merge Sort)");
		System.out.println("3. First fifty cities sorted by name (Insertion Sort)");
		System.out.println("4. Last fifty cities sorted by name descending (Merge Sort)");
		System.out.println("5. Fifty most populous cities in named state");
		System.out.println("6. All cities matching a name sorted by population");
		System.out.println("9. Quit");
	}

	/* Takes and processes user input as a query */
	public void getInput() {
		int choice;
		do {
			printMenu();
			choice = Prompt.getInt("Enter selection");
			processChoice(choice);
		} while (choice != 9);
	}

	/* Conducts appropriate sorting based on user choice */
	public void processChoice(int choice) {
		long startMillisec, endMillisec;
		switch (choice) {
			case 1:
				startMillisec = System.currentTimeMillis();
				selectionSort(cities);
				endMillisec = System.currentTimeMillis();
				System.out.println("\nFifty least populous cities");
				displayCities(cities.subList(0, 50));
				System.out.println("\nElapsed Time " + (endMillisec - startMillisec) + " milliseconds\n");
				break;
			case 2:
				startMillisec = System.currentTimeMillis();
				mergeSortDescending(cities, false);
				endMillisec = System.currentTimeMillis();
				System.out.println("\nFifty most populous cities");
				displayCities(cities.subList(0, 50));
				System.out.println("\nElapsed Time " + (endMillisec - startMillisec) + " milliseconds\n");
				break;
			case 3:
				startMillisec = System.currentTimeMillis();
				insertionSortByName(cities);
				endMillisec = System.currentTimeMillis();
				System.out.println("\nFifty cities sorted by name");
				displayCities(cities.subList(0, 50));
				System.out.println("\nElapsed Time " + (endMillisec - startMillisec) + " milliseconds\n");
				break;
			case 4:
				startMillisec = System.currentTimeMillis();
				mergeSortDescending(cities, true);
				endMillisec = System.currentTimeMillis();
				System.out.println("\nFifty cities sorted by name descending");
				displayCities(cities.subList(0, 50));
				System.out.println("\nElapsed Time " + (endMillisec - startMillisec) + " milliseconds\n");
				break;
			case 5:
				boolean found = false;
				String state = "";
				System.out.println();
				while (!found) {
					state = Prompt.getString("Enter state name (ie. Alabama)").trim();
					for (int i = 0; i < cities.size() - 1; i++) {
						if (cities.get(i).getState().equals(state)) {
							found = true;
							state = cities.get(i).getState();
						}
					}
				}
				List<City> sortedStateCities = new ArrayList<>();
				for (City city : cities) {
					if (city.getState().equals(state))
						sortedStateCities.add(city);
				}
				mergeSortDescending(sortedStateCities, false);
				System.out.println("\nFifty most populous cities in " + state);
				displayCities(sortedStateCities.subList(0, Math.min(50, sortedStateCities.size())));
				System.out.println();
				break;
			case 6:
				boolean match = false;
				String name = "";
				System.out.println();
				while (!match) {
					name = Prompt.getString("Enter city name").trim();
					for (int i = 0; i < cities.size() - 1; i++) {
						if (cities.get(i).getName().equals(name)) {
							match = true;
							name = cities.get(i).getName();
						}
					}
				}
				List<City> sortedCities = new ArrayList<>();
				for (City city : cities) {
					if (city.getName().equals(name))
						sortedCities.add(city);
				}
				mergeSortDescending(sortedCities, false);
				System.out.println("\nCity " + name + " by population");
				displayCities(sortedCities);
				System.out.println();
				break;
			case 9:
				System.out.print("\nThanks for using Population!");
				break;
		}
	}

	/* Prints out List of sorted data with headers */
	public void displayCities(List<City> cities) {
		System.out.printf(" %-25s %-22s %-14s %-12s%n", "State", "City", "Type", "Population");
		for (int i = 0; i < cities.size(); i++)
			System.out.printf("%2d: %s%n", i + 1, cities.get(i));
	}

	/* Uses selection sort to sort 50 least populous cities */
	public void selectionSort(List<City> cities) {
		for (int i = 0; i < cities.size() - 1; i++) {
			int minIdx = i;
			for (int j = i + 1; j < cities.size(); j++) {
				if (cities.get(j).compareTo(cities.get(minIdx)) < 0)
					minIdx = j;
			}
			City temp = cities.get(i);
			cities.set(i, cities.get(minIdx));
			cities.set(minIdx, temp);
		}
	}

	/* Uses insertion sort to sort 50 cities by name ascending */
	public void insertionSortByName(List<City> cities) {
		CityComparatorByName compare = new CityComparatorByName();
		for (int i = 1; i < cities.size(); i++) {
			City c1 = cities.get(i);
			int j = i - 1;
			while (j >= 0 && compare.compare(cities.get(j), c1) > 0) {
				cities.set(j + 1, cities.get(j));
				j--;
			}
			cities.set(j + 1, c1);
		}
	}

	/**
	 *	Uses merge sort to sort 50 most populous cities, 50 cities by name descending, 50 most
	 *	populous cities by user-inputted state, and all cities matching user-inputted name
	 */
	public void mergeSortDescending(List<City> cities, boolean sortByName) {
		if (cities.size() <= 1)
			return;
		int middle = cities.size() / 2;
		List<City> left = new ArrayList<>(cities.subList(0, middle));
		List<City> right = new ArrayList<>(cities.subList(middle, cities.size()));
		mergeSortDescending(left, sortByName);
		mergeSortDescending(right, sortByName);
		mergeDescending(cities, left, right, sortByName);
	}

	/* Merges 2 sorted subLists into main List in descending order */
	private void mergeDescending(List<City> cities, List<City> left, List<City> right, boolean sortByName) {
		int i = 0, j = 0, a = 0;
		while (i < left.size() && j < right.size()) {
			int comparison;
			if (sortByName)
				comparison = left.get(i).getName().compareTo(right.get(j).getName());
			else
				comparison = Integer.compare(left.get(i).getPopulation(), right.get(j).getPopulation());
			if (comparison > 0)
				cities.set(a++, left.get(i++));
			else
				cities.set(a++, right.get(j++));
		}
		while (i < left.size())
			cities.set(a++, left.get(i++));
		while (j < right.size())
			cities.set(a++, right.get(j++));
	}
}
