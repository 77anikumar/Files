import java.util.Comparator;
/**
 *	CityComparatorByName - compares city names and returns integer value of their difference.
 *
 *	@author	Ani Kumar
 *	@since	December 10, 2024
 */
public class CityComparatorByName implements Comparator<City> {
    public int compare(City city1, City city2) {
        int nameCompare = city1.getName().compareTo(city2.getName());
        if (nameCompare != 0)
            return nameCompare;
        return city1.getPopulation() - city2.getPopulation();
    }
}
