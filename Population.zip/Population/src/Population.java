import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
/**
 *	Population - implements different sorting methods and organizes a large set of data
 *	of over 30,000 USA cities and their populations.
 *	Requires FileUtils and Prompt classes.
 *
 *	@author	Ani Kumar
 *	@since	December 10, 2024
 */
public class Population {
	private List<City> cities; 								// list of cities
	private final String DATA_FILE = "usPopData2017.txt";	// US data file

	/* Constructor that initializes fields. */
	public Population() {
		cities = new ArrayList<>();
	}

	/* Main that executes program. */
	public static void main(String[] args) {
		Population population = new Population();
		population.runner();
	}

	/* Runner that calls other methods in order. */
	public void runner() {
		loadCities();
		printIntroduction();
		getInput();
	}

	/* Takes and processes input as a query. */
	public void getInput() {
		int choice;
		do {
			printMenu();
			choice = Prompt.getInt("Enter selection");
			processChoice(choice);
		} while (choice != 9);
	}

	public void processChoice(int choice) {
		SortMethods sorter = new SortMethods();
		long startMillisec, endMillisec;
		switch (choice) {
			case 1:
				System.out.println("\nFifty least populous cities");
				startMillisec = System.currentTimeMillis();
				sorter.selectionSort(cities);
				endMillisec = System.currentTimeMillis();
				displayCities(cities.subList(0, Math.min(50, cities.size())));
				System.out.println("\nElapsed Time " + (endMillisec - startMillisec) + " milliseconds\n");
				break;
			case 2:
				System.out.println("\nFifty most populous cities");
				startMillisec = System.currentTimeMillis();
				sorter.mergeSortDescending(cities, false);
				endMillisec = System.currentTimeMillis();
				displayCities(cities.subList(0, Math.min(50, cities.size())));
				System.out.println("\nElapsed Time " + (endMillisec - startMillisec) + " milliseconds\n");
				break;
			case 3:
				System.out.println("\nFifty cities sorted by name");
				startMillisec = System.currentTimeMillis();
				sorter.insertionSortByName(cities);
				endMillisec = System.currentTimeMillis();
				displayCities(cities.subList(0, Math.min(50, cities.size())));
				System.out.println("\nElapsed Time " + (endMillisec - startMillisec) + " milliseconds\n");
				break;
			case 4:
				System.out.println("\nLast fifty cities sorted by name descending");
				startMillisec = System.currentTimeMillis();
				sorter.mergeSortByNameDescending(cities);
				endMillisec = System.currentTimeMillis();
				displayCities(cities.subList(0, Math.min(50, cities.size())));
				System.out.println("\nElapsed Time " + (endMillisec - startMillisec) + " milliseconds\n");
				break;
			case 5:
				String state = Prompt.getString("\nEnter state name (ie. Alabama)");
				System.out.println("\nFifty most populous cities in " + state);
				List<City> filteredStateCities = new ArrayList<>();
				for (City city : cities) {
					if (city.getState().equalsIgnoreCase(state)) {
						filteredStateCities.add(city);
					}
				}
				sorter.mergeSortDescending(filteredStateCities, false);
				displayCities(filteredStateCities.subList(0, Math.min(50, filteredStateCities.size())));
				break;
			case 6:
				String name = Prompt.getString("\nEnter city name");
				System.out.println("\nCity " + name + " by population:");
				List<City> filteredCities = new ArrayList<>();
				for (City city : cities) {
					if (city.getName().equalsIgnoreCase(name)) {
						filteredCities.add(city);
					}
				}
				sorter.mergeSortDescending(filteredCities, false);
				displayCities(filteredCities);
				System.out.print("\n");
				break;
			case 9:
				System.out.print("\nThanks for using Population!");
				break;
		}
	}

	public void loadCities() {
		try (Scanner scanner = FileUtils.openToRead(DATA_FILE)) {
			scanner.useDelimiter("[\t\n]");
			while (scanner.hasNext()) {
				String state = scanner.next();
				String name = scanner.next();
				String designation = scanner.next();
				int population = scanner.nextInt();
				cities.add(new City(name, state, designation, population));
			}
		} catch (Exception e) {
			System.err.println("Error loading city data: " + e.getMessage());
		}
	}

	/**	Prints the introduction to Population */
	public void printIntroduction() {
		System.out.println("   ___                  _       _   _");
		System.out.println("  / _ \\___  _ __  _   _| | __ _| |_(_) ___  _ __ ");
		System.out.println(" / /_)/ _ \\| '_ \\| | | | |/ _` | __| |/ _ \\| '_ \\ ");
		System.out.println("/ ___/ (_) | |_) | |_| | | (_| | |_| | (_) | | | |");
		System.out.println("\\/    \\___/| .__/ \\__,_|_|\\__,_|\\__|_|\\___/|_| |_|");
		System.out.println("           |_|");
		System.out.println();
	}

	/** Print out the choices for population sorting */
	public void printMenu() {
		System.out.println("1. Fifty least populous cities in USA (Selection Sort)");
		System.out.println("2. Fifty most populous cities in USA (Merge Sort)");
		System.out.println("3. First fifty cities sorted by name (Insertion Sort)");
		System.out.println("4. Last fifty cities sorted by name descending (Merge Sort)");
		System.out.println("5. Fifty most populous cities in named state");
		System.out.println("6. All cities matching a name sorted by population");
		System.out.println("9. Quit");
	}

	public void displayCities(List<City> cities) {
		System.out.printf(" %-25s %-22s %-14s %-12s%n", "State", "City", "Type", "Population");
		for (int i = 0; i < cities.size(); i++)
			System.out.printf("%2d: %s%n", i + 1, cities.get(i));
	}
}

class SortMethods {
	public void selectionSort(List<City> cities) {
		int n = cities.size();
		for (int i = 0; i < n - 1; i++) {
			int minIdx = i;
			for (int j = i + 1; j < n; j++) {
				if (cities.get(j).compareTo(cities.get(minIdx)) < 0)
					minIdx = j;
			}
			City temp = cities.get(i);
			cities.set(i, cities.get(minIdx));
			cities.set(minIdx, temp);
		}
	}

	public void insertionSortByName(List<City> cities) {
		int n = cities.size();
		for (int i = 1; i < n; i++) {
			City key = cities.get(i);
			int j = i - 1;
			while (j >= 0 && cities.get(j).getName().compareTo(key.getName()) > 0) {
				cities.set(j + 1, cities.get(j));
				j--;
			}
			cities.set(j + 1, key);
		}
	}

	public void mergeSortDescending(List<City> cities, boolean sortByName) {
		if (cities.size() <= 1) {
			return;
		}
		int mid = cities.size() / 2;
		List<City> left = new ArrayList<>(cities.subList(0, mid));
		List<City> right = new ArrayList<>(cities.subList(mid, cities.size()));
		mergeSortDescending(left, sortByName);
		mergeSortDescending(right, sortByName);
		mergeDescending(cities, left, right, sortByName);
	}

	private void mergeDescending(List<City> cities, List<City> left, List<City> right, boolean sortByName) {
		int i = 0, j = 0, k = 0;
		while (i < left.size() && j < right.size()) {
			int comparison;
			if (sortByName)
				comparison = left.get(i).getName().compareTo(right.get(j).getName());
			else
				comparison = Integer.compare(left.get(i).getPopulation(), right.get(j).getPopulation());
			if (comparison > 0)
				cities.set(k++, left.get(i++));
			else
				cities.set(k++, right.get(j++));
		}
		while (i < left.size())
			cities.set(k++, left.get(i++));
		while (j < right.size())
			cities.set(k++, right.get(j++));
	}

	/*public void mergeSortByPopulationDescending(List<City> cities) {
		mergeSortDescending(cities, false); // Sort by population
	}*/

	public void mergeSortByNameDescending(List<City> cities) {
		mergeSortDescending(cities, true); // Sort by name
	}
}