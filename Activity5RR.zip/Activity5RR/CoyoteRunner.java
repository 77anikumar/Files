/**
 * Places 2 Coyotes on a 10 by 10 grid.
 *
 * @author	Ani Kumar
 * @since	March 28, 2025
 */

import info.gridworld.actor.Actor;
import info.gridworld.grid.Location;
import info.gridworld.actor.ActorWorld;
import info.gridworld.grid.BoundedGrid;

public class CoyoteRunner {
    public static void main(String[] args) {
        BoundedGrid<Actor> mygrid = new BoundedGrid<>(10, 10);
        ActorWorld world = new ActorWorld(mygrid);
        world.add(new Location(4, 4), new Coyote());
        world.add(new Location(5, 8), new Coyote());
        world.show();
    }
}