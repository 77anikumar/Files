/**
 * The Coyote drops Stones as he wanders around the grid. He moves in straight
 * lines, but stops every couple steps to drop a stone and change direction.
 *
 * @author	Ani Kumar
 * @since	March 28, 2025
 */

import info.gridworld.actor.Actor;
import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;
import info.gridworld.actor.Critter;
import java.util.ArrayList;

public class Coyote extends Critter {
	// stores the 8 compass directions Coyote can move in
	private int[] dirs = { Location.NORTH, Location.NORTHEAST,
			Location.EAST, Location.SOUTHEAST, Location.SOUTH,
			Location.SOUTHWEST, Location.WEST, Location.NORTHWEST };
	private final int DURATION = 5;	// how long Coyote walks or sleeps for
	private boolean isSleeping;		// indicates if Coyote is sleeping
	private boolean hasExploded;	// indicates if Coyote has exploded
	private boolean hasHitObst;		// indicates if Coyote has hit obstacle
	private int sleepLeft;			// number of remaining sleep cycles
	private int stepsLeft;			// number of remaining movement cycles

	/* Constructor that initializes fields. */
	public Coyote() {
		setColor(null);
		setDirection(dirs[(int)(Math.random() * 8)]);
		sleepLeft = stepsLeft = DURATION;
		isSleeping = hasExploded = hasHitObst = false;
	}

	/**
	 * Makes Coyote move depending on the validity and contents of given location.
	 * If location is out of bounds or occupied, Coyote will not move.
	 *
	 * @param loc		the location to be moved to.
	 */
	public void makeMove(Location loc) {
		if (hasExploded)
			return;
		Grid grid = getGrid();
		if (!isSleeping) {
			if (!grid.isValid(loc) || grid.get(loc) instanceof Actor) {
				stepsLeft = DURATION;
				hasHitObst = true;
				isSleeping = true;
			} else {
				moveTo(loc);
				stepsLeft--;
				if (stepsLeft == 0) {
					stepsLeft = DURATION;
					isSleeping = true;
				}
			}
		} else {
			sleepLeft--;
			if (sleepLeft == 0) {
				sleepLeft = DURATION;
				isSleeping = false;
				ArrayList<Location> validLocs = getGrid().getValidAdjacentLocations(getLocation());
				Location randLoc = validLocs.get((int)(Math.random() * validLocs.size()));
				setDirection(getLocation().getDirectionToward(randLoc));
				if (!hasHitObst)
					placeStone();
				hasHitObst = false;
			}
		}
	}

	/**
	 * Returns an ArrayList of valid move locations for Coyote.
	 *
	 * @return 			ArrayList containing location in front of Coyote.
	 */
	public ArrayList<Location> getMoveLocations() {
		ArrayList<Location> locs = new ArrayList<>();
		if (!hasExploded) {
			Location loc = getLocation().getAdjacentLocation(getDirection());
			if (getGrid().isValid(loc))
				locs.add(loc);
		}
		return locs;
	}

	/**
	 * Processes actors adjacent to Coyote. If the actor is a Boulder,
	 * it explodes and Ccoyote is removed from the grid.
	 *
	 * @param actors	the ArrayList with the actor to be processed.
	 */
	public void processActors(ArrayList<Actor> actors) {
		if (actors.isEmpty())
			return;
		Actor actor = actors.get(0);
		if (actor instanceof Boulder) {
			Kaboom boom = new Kaboom();
			Location loc = actor.getLocation();
			actor.removeSelfFromGrid();
			boom.putSelfInGrid(getGrid(), loc);
			hasExploded = true;
			removeSelfFromGrid();
		}
	}

	/**
	 * Getter that checks the location in front of Coyote.
	 * @return			ArrayList containing actor in front of Coyote.
	 */
	public ArrayList<Actor> getActors() {
		ArrayList<Actor> actors = new ArrayList<>();
		Location loc = getLocation().getAdjacentLocation(getDirection());
		if (getGrid().isValid(loc))
			actors.add(getGrid().get(loc));
		return actors;
	}

	/* Places a stone at a random adjacent location. */
	public void placeStone() {
		ArrayList<Location> locs = new ArrayList<>();
		for (int dir : dirs) {
			Location loc1 = getLocation().getAdjacentLocation(dir);
			if (getGrid().isValid(loc1) && getGrid().get(loc1) == null)
				locs.add(loc1);
		}
		if (locs.isEmpty())
			return;
		Location loc = locs.get((int)(Math.random() * locs.size()));
		Stone stone = new Stone();
		stone.putSelfInGrid(getGrid(), loc);
	}
}