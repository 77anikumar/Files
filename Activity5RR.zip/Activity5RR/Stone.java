/**
 * Defines the Stone actor.
 * 
 * @author	Ani Kumar
 * @since	March 28, 2025
 */

import info.gridworld.actor.Actor;
import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;
import info.gridworld.actor.Rock;
import java.awt.Color;

public class Stone extends Rock {
	private int lifetime;				// lifetime of Stone
	private final int threshold = 3;	// determines when Stone turns green
	
	public Stone() {
		setColor(null);
		lifetime = (int)(Math.random() * 200 + 1);
	}
	
	public Stone(int life) {
		setColor(null);
		lifetime = life;
	}
	
	/* Counts down actor's lifetime then replaces with Boulder. */
	public void act() {
		lifetime--;
		if (lifetime < threshold && lifetime > 0)
			setColor(Color.GREEN);
		if (lifetime == 0) {
			Boulder boulder = new Boulder();
			boulder.putSelfInGrid(getGrid(), getLocation());
		}
	}
}
