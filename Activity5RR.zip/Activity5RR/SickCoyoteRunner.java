/**
 * Runs the SickCoyote class
 *
 * @author	Ani Kumar
 * @since	March 28, 2025
 */

import info.gridworld.actor.ActorWorld;
import info.gridworld.grid.BoundedGrid;
import info.gridworld.grid.Location;

public class SickCoyoteRunner {
    public static void main(String[] args) {
        ActorWorld world = new ActorWorld(new BoundedGrid<>(5, 5));
        world.add(new Location(1, 1), new SickCoyote());
        world.add(new Location(2, 2), new SickCoyote(5));
        world.add(new Location(3, 3), new SickCoyote(7));
        world.add(new Location(4, 4), new SickCoyote(9));
        world.show();
    }
}