/**
 * The Roadrunner (RR) can move several cells at once and stops before hitting Stones and the edge.
 * of the grid. Boulders are a problem because they explode and RR is removed from the grid.
 * When RR hits a Coyote, RR is fine, but the Coyote is knocked back and stunned for some time.
 *
 * @author	Ani Kumar
 * @since	March 28, 2025
 */

import info.gridworld.actor.Actor;
import info.gridworld.actor.Critter;
import info.gridworld.grid.Location;
import info.gridworld.grid.Grid;
import java.util.ArrayList;

public class RR extends Critter {
	private boolean hasExploded; // indicates if RR has exploded

	/* Constructor that initializes fields. */
	public RR() {
		setColor(null);
		hasExploded = false;
		setDirection(Location.NORTH);
	}

	/**
	 * Gets all valid move locations in a straight line up to 3 spaces away.
	 * RR can pass through empty cells but stops at a Boulder, Coyote,
	 * Stone, SickCoyote, Kaboom, or the edge of the grid.
	 *
	 * @return 				ArrayList of valid move locations.
	 */
	public ArrayList<Location> getMoveLocations() {
		int[] dirs = { Location.NORTH, Location.EAST, Location.SOUTH, Location.WEST };
		ArrayList<Location> moveLocs = new ArrayList<>();
		Grid<Actor> grid = getGrid();
		if (hasExploded) return moveLocs;
		for (int dir : dirs) { // checks movement in all directions
			boolean isBlocked = false;
			Location oneAway = getLocation().getAdjacentLocation(dir);
			for (int i = 0; i < 3 && !isBlocked; i++) { // move up to 3 spaces
				if (!grid.isValid(oneAway))
					break; // out of bounds
				Actor obstacle = grid.get(oneAway);
				if (obstacle == null)
					moveLocs.add(oneAway); // empty space -> keep moving
				else if (obstacle instanceof Coyote || obstacle instanceof Boulder) {
					moveLocs.add(oneAway);
					isBlocked = true; // can move here, stops further movement
				} else
					isBlocked = true; // can't move past here
				oneAway = oneAway.getAdjacentLocation(dir);
			}
		}
		return moveLocs;
	}

	/**
	 * Moves RR to a given location. If RR lands on a Coyote, the Coyote
	 * is removed, and a SickCoyote is placed in a random adjacent empty spot.
	 * If RR lands on a Boulder, the Boulder is replaced with a Kaboom,
	 * and RR is removed.
	 *
	 * @param destination	The target location for RR to move.
	 */
	public void makeMove(Location destination) {
		if (hasExploded || destination.equals(getLocation()))
			return;
		Grid<Actor> grid = getGrid();
		Actor occupant = grid.get(destination);
		if (occupant == null)
			moveTo(destination);
		else if (occupant instanceof Coyote) { // remove Coyote, move RR there, place SickCoyote randomly
			occupant.removeSelfFromGrid();
			moveTo(destination);
			SickCoyote sickCoyote = new SickCoyote();
			ArrayList<Location> emptySpaces = grid.getEmptyAdjacentLocations(destination);
			if (!emptySpaces.isEmpty())
				sickCoyote.putSelfInGrid(grid, emptySpaces.get((int) (Math.random() * emptySpaces.size())));
		} else if (occupant instanceof Boulder) { // replace Boulder with Kaboom, remove RR from grid
			occupant.removeSelfFromGrid();
			Kaboom explosion = new Kaboom();
			explosion.putSelfInGrid(grid, destination);
			hasExploded = true;
			removeSelfFromGrid();
		}
	}
}