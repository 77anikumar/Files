/**
 * The SickCoyote will act liked the stunned Coyote after he is hit by the Roadrunner.
 * When its lifetime reaches 0, it is replaced by a new (healthy) Coyote.
 *
 * @author	Ani Kumar
 * @since	March 28, 2025
 */

import info.gridworld.actor.Actor;
import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;

public class SickCoyote extends Actor {
    private int lifetime;       // lifetime of SickCoyote
    private int threshold = 10; // length of lifetime of SickCoyote

    public SickCoyote() {
        setColor(null);
        lifetime = threshold;
    }

    public SickCoyote(int life) {
        setColor(null);
        lifetime = life;
    }

    /* Counts down actor's lifetime then replaces with Coyote. */
    public void act() {
        lifetime--;
        if (lifetime == 0)
            replaceWithCoyote();
    }

    /* Replaces SickCoyote actor with a Coyote actor. */
    private void replaceWithCoyote() {
        Grid<Actor> grid = getGrid();
        if (grid != null) {
            Location loc = getLocation();
            removeSelfFromGrid();
            Coyote healthyCoyote = new Coyote();
            healthyCoyote.putSelfInGrid(grid, loc);
        }
    }
}