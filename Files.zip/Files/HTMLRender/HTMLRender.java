import java.util.Scanner;

/**
 * HTMLRender
 * This program processes and renders HTML text in a JFrame window.
 * It uses the HTMLUtilities class for tokenizing and the SimpleHtmlRenderer for rendering.
 * The supported tags include:
 * - <html>, </html>: Start/end of HTML document.
 * - <body>, </body>: Start/end of the HTML body.
 * - <p>, </p>: Start/end of a paragraph with line breaks.
 * - <hr>: Creates a horizontal rule.
 * - <br>: Inserts a line break.
 * - <b>, </b>: Bold text.
 * - <i>, </i>: Italicized text.
 * - <q>, </q>: Inline quotation marks.
 * - <h1> through <h6>: Headers with varying sizes and line length limits.
 * - <pre>, </pre>: Preformatted text that preserves whitespace and formatting.
 *
 * @author Ani Kumar
 * @version November 20, 2024
 */
public class HTMLRender {
	private static final int MAX_PLAIN_LENGTH = 80; // for plain, bold, and italics
	private static final int MAX_H1_LENGTH = 40;	// for header 1
	private static final int MAX_H2_LENGTH = 50;	// for header 2
	private static final int MAX_H3_LENGTH = 60;	// for header 3
	private static final int MAX_H4_LENGTH = 80;	// for header 4
	private static final int MAX_H5_LENGTH = 100;	// for header 5
	private static final int MAX_H6_LENGTH = 120;	// for header 6

	private String[] tokens;                    	// the array holding all the tokens of the HTML file
	private final int TOKEN_CAPACITY = 100000;  	// size of array
	private HTMLUtilities htmlUtil;             	// HTMLUtilities used in tester

	private SimpleHtmlRenderer render;				// instance of SimpleHtmlRenderer
	private HtmlPrinter browser;					// instance of HtmlPrinter

	private enum State {							// Enum for states (plain, bold, italic, headers 1 - 6)
		PLAIN,
		BOLD,
		ITALIC,
		HEADER1,
		HEADER2,
		HEADER3,
		HEADER4,
		HEADER5,
		HEADER6
	}

	/* Constructor that initializes fields. */
	public HTMLRender() {
		tokens = new String[TOKEN_CAPACITY];
		htmlUtil = new HTMLUtilities();
		render = new SimpleHtmlRenderer();
		browser = render.getHtmlPrinter();
	}

	/* Main that executes program. */
	public static void main(String[] args) {
		HTMLRender html = new HTMLRender();
		String inputFile = (args.length == 0) ? "" : args[0];
		if (!inputFile.isEmpty())
			html.run(inputFile);
	}

	/* Reads and processes the given HTML file, rendering it using SimpleHtmlRenderer. */
	public void run(String fileName) {
		Scanner input = FileUtils.openToRead(fileName);
		int tokenCount = 0;
		String[] rawTokens = new String[TOKEN_CAPACITY];
		// Tokenize the input file line by line
		while (input.hasNext()) {
			String currentLine = input.nextLine();
			String[] lineTokens = htmlUtil.tokenizeHTMLString(currentLine);
			for (String token : lineTokens)
				rawTokens[tokenCount++] = token;
		}
		input.close();
		// Adjust tokens to ignore outermost <html> and <body> tags
		if (tokenCount - 4 >= 0)
			System.arraycopy(rawTokens, 2, tokens, 0, tokenCount - 4);
		renderTokens(tokenCount - 4);
	}

	/**
	 * Processes and renders tokens from the tokens array.
	 *
	 * @param tokenCount The number of tokens to process.
	 */
	private void renderTokens(int tokenCount) {
		int currentIndex = 0;
		int currentLineLength = 0;
		State currentState = State.PLAIN; // Initialize as plain text
		int stateEndIndex = -1;
		while (currentIndex < tokenCount) {
			if (currentIndex == stateEndIndex)
				currentState = State.PLAIN;
			if (!isHTMLTag(tokens[currentIndex])) {
				// Handle plain text or punctuation
				if (tokens[currentIndex].length() == 1 && htmlUtil.isPunct(tokens[currentIndex].charAt(0))) {
					if (currentLineLength >= MAX_PLAIN_LENGTH) {
						currentLineLength = 0;
						browser.println();
					}
					renderWithState(tokens[currentIndex], currentState);
					currentLineLength++;
				} else {
					if (currentLineLength + tokens[currentIndex].length() >= MAX_PLAIN_LENGTH) {
						browser.println();
						currentLineLength = 0;
					}
					renderWithState(" " + tokens[currentIndex], currentState);
					currentLineLength += tokens[currentIndex].length() + 1;
				}
			} else {
				// Handle HTML tags
				String currentTag = tokens[currentIndex];
				int tagStartIndex = currentIndex;
				if (currentTag.equalsIgnoreCase("<p>") || currentTag.equalsIgnoreCase("</p>")) {
					currentLineLength = 0;
					browser.println();
					browser.println();
				} else if (currentTag.equalsIgnoreCase("</q>")) {
					browser.print("\"");
					currentLineLength++;
				} else if (isClosingTag(currentTag)) {
					// Skip closing tags
				} else if (currentTag.equalsIgnoreCase("<hr>")) {
					browser.printHorizontalRule();
					currentLineLength = 0;
				} else if (currentTag.equalsIgnoreCase("<br>")) {
					browser.printBreak();
					currentLineLength = 0;
				} else {
					while (!tagsMatch(currentTag, tokens[currentIndex])) currentIndex++;
					if (currentTag.equalsIgnoreCase("<b>")) {
						currentState = State.BOLD;
						stateEndIndex = currentIndex;
						currentIndex = tagStartIndex;
					} else if (currentTag.equalsIgnoreCase("<i>")) {
						currentState = State.ITALIC;
						stateEndIndex = currentIndex;
						currentIndex = tagStartIndex;
					} else if (currentTag.equalsIgnoreCase("<q>")) {
						browser.print(" \"");
						currentIndex = tagStartIndex;
						currentLineLength++;
					} else if (currentTag.startsWith("<h")) {
						browser.println();
						renderHeader(currentTag, tagStartIndex, currentIndex);
						browser.println();
						currentLineLength = 0;
					} else if (currentTag.equalsIgnoreCase("<pre>")) {
						for (int i = tagStartIndex + 1; i < currentIndex; i++) {
							browser.printPreformattedText(tokens[i]);
							browser.println();
						}
					}
				}
			}
			currentIndex++;
		}
	}

	/* Renders line-wrapped header tags. */
	private void renderHeader(String tag, int start, int end) {
		int headerLevel = tag.charAt(2) - '0';
		int maxHeaderLength;
		// Assign max length based on header level
		switch (headerLevel) {
			case 1 -> maxHeaderLength = MAX_H1_LENGTH;
			case 2 -> maxHeaderLength = MAX_H2_LENGTH;
			case 3 -> maxHeaderLength = MAX_H3_LENGTH;
			case 4 -> maxHeaderLength = MAX_H4_LENGTH;
			case 5 -> maxHeaderLength = MAX_H5_LENGTH;
			case 6 -> maxHeaderLength = MAX_H6_LENGTH;
			default -> maxHeaderLength = MAX_PLAIN_LENGTH;
		}
		int currentLineLength = 0;
		for (int i = start + 1; i < end; i++) {
			if (tokens[i].length() == 1 && htmlUtil.isPunct(tokens[i].charAt(0))) {
				if (currentLineLength >= maxHeaderLength) {
					currentLineLength = 0;
					browser.println();
				}
				renderWithState(tokens[i], State.values()[headerLevel + 2]);
				currentLineLength++;
			} else {
				if (currentLineLength + tokens[i].length() >= maxHeaderLength) {
					browser.println();
					currentLineLength = 0;
				}
				renderWithState(" " + tokens[i], State.values()[headerLevel + 2]);
				currentLineLength += tokens[i].length() + 1;
			}
		}
	}

	/* Renders content based on the current state. */
	private void renderWithState(String text, State state) {
		switch (state) {
			case PLAIN -> browser.print(text);
			case BOLD -> browser.printBold(text);
			case ITALIC -> browser.printItalic(text);
			case HEADER1 -> browser.printHeading1(text);
			case HEADER2 -> browser.printHeading2(text);
			case HEADER3 -> browser.printHeading3(text);
			case HEADER4 -> browser.printHeading4(text);
			case HEADER5 -> browser.printHeading5(text);
			case HEADER6 -> browser.printHeading6(text);
		}
	}

	/* Checks if a string is an HTML tag based on what it starts and ends with. */
	private boolean isHTMLTag(String str) {
		return str.startsWith("<") && str.endsWith(">");
	}

	/* Determines if a tag is closing based on what it starts with. */
	private boolean isClosingTag(String tag) {
		return tag.startsWith("</");
	}

	/* Verifies if an opening and closing pair are corresponding. */
	private boolean tagsMatch(String openTag, String closeTag) {
		return ("</" + openTag.substring(1)).equalsIgnoreCase(closeTag);
	}
}