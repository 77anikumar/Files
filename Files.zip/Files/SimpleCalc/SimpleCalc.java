import java.util.ArrayList;
import java.util.List;		// used by expression evaluator

/**
 *	Using stacks to emulate an infix arithmetic calculator
 *
 *	@author	Ani Kumar
 *	@since	February 26, 2025
 */
public class SimpleCalc {
	private ExprUtils utils;                	// expression utilities
	private ArrayStack<Double> valueStack;		// value stack
	private ArrayStack<String> operatorStack;	// operator stack
	private List<Identifier> identifiers;		// list of identifiers

	/* Constructor that initializes fields */
	public SimpleCalc() {
		utils = new ExprUtils();
		valueStack = new ArrayStack<>();
		operatorStack = new ArrayStack<>();
		identifiers = new ArrayList<>();
	}

	/* Main that executes program */
	public static void main(String[] args) {
		SimpleCalc sc = new SimpleCalc();
		sc.run();
	}

	/* Runner method that prints messages and makes intial call */
	public void run() {
		System.out.println("\nWelcome to SimpleCalc!!!\n");
		initCalc();
		runCalc();
		System.out.println("\nThanks for using SimpleCalc! Goodbye.\n");
	}

	/* Print help */
	public void printHelp() {
		System.out.println("Help:");
		System.out.println("  h - this message\n  q - quit\n");
		System.out.println("Expressions can contain:");
		System.out.println("  integers or decimal numbers");
		System.out.println("  arithmetic operators +, -, *, /, %, ^");
		System.out.println("  parentheses '(' and ')'\n");
	}

	/* Print variables */
	public void printVars() {
		System.out.println("Identifiers:");
		for (Identifier id : identifiers)
			System.out.printf(" %-7s = %.7f\n", id.getName(), id.getValue());
	}

	/* Initializes variables 'e' and 'pi' in database */
	public void initCalc() {
		identifiers.add(new Identifier("e", Math.E));
		identifiers.add(new Identifier("pi", Math.PI));
	}

	/**
	 * Prompt the user for expressions, run the expression evaluator, and display the answer
	 */
	public void runCalc() {
		String input = "";
		while (!input.equalsIgnoreCase("q")) {
			input = Prompt.getString("");
			if (input.equalsIgnoreCase("h"))
				printHelp();
			else if (input.equalsIgnoreCase("q"))
				return;
			else if (input.equalsIgnoreCase("l"))
				printVars();
			else {
				List<String> tokens = utils.tokenizeExpression(input);
				if (tokens.size() > 2 && tokens.get(1).equals("=")) {
					String idName = tokens.get(0);
					if (idName.equals("e"))
						System.out.println(Math.E);
					else if (idName.equals("pi"))
						System.out.println(Math.PI);
					else if (!isValidIdentifier(idName))
						System.out.println("0.0");
					else {
						tokens = tokens.subList(2, tokens.size());
						double idValue = evaluateExpression(tokens);
						setIdentifier(idName, idValue);
						System.out.printf(" %-7s = %.7f\n", idName, idValue);
					}
				} else {
					double answer = evaluateExpression(tokens);
					System.out.println(answer);
				}
			}
		}
	}

	/**
	 * Evaluate expression and return the value
	 *
	 * @param tokens	a List of String tokens making up an arithmetic expression
	 * @return 			value of the evaluated expression
	 */
	public double evaluateExpression(List<String> tokens) {
		for (String token : tokens) {
			if (isOperand(token)) {
				valueStack.push(Double.parseDouble(token));
			} else if (isValidIdentifier(token)) {
				valueStack.push(getIdentifierValue(token));
			} else if (isOperator(token)) {
				if (operatorStack.isEmpty() || token.equals("("))
					operatorStack.push(token);
				else if (token.equals(")")) {
					String nextOp = operatorStack.peek();
					while (!nextOp.equals("(")) { // processes until opening parenthesis
						processOperator();
						nextOp = operatorStack.peek();
					}
					operatorStack.pop();
				}
				else { // non-parenthesis operator
					String nextOp = operatorStack.peek();
					while (!operatorStack.isEmpty() && hasPrecedence(token, nextOp)) {
						processOperator();
						if (!operatorStack.isEmpty())
							nextOp = operatorStack.peek();
					}
					operatorStack.push(token);
				}
			}
		}
		while (!operatorStack.isEmpty())
			processOperator();
		return valueStack.pop();
	}

	/**
	 * Helper method that checks if a String contains at least one digit
	 *
	 * @param token		a String that could contain an operand
	 * @return true 	if String contains at least one digit, false otherwise
	 */
	private boolean isOperand(String token) {
		try {
			Double.parseDouble(token);
			return true;
		} catch (NumberFormatException e) {
			return false;
		}
	}

	/**
	 * Helper method that checks if a String is a single operator (+, -, *, /, %)
	 *
	 * @param token		a String that could be an operator
	 * @return true 	if String is an operator, false otherwise
	 */
	private boolean isOperator(String token) {
		return token.length() == 1 && utils.isOperator(token.charAt(0));
    }

	/* Evaluates expression of 2 operands and 1 operator and pushes answer onto valueStack */
	private void processOperator() {
		String operator = operatorStack.pop();
		double b = valueStack.pop();
		double a = valueStack.pop();
		switch (operator) {
			case "+":
				valueStack.push(a + b);
				break;
			case "-":
				valueStack.push(a - b);
				break;
			case "*":
				valueStack.push(a * b);
				break;
			case "/":
				valueStack.push(a / b);
				break;
			case "%":
				valueStack.push(a % b);
				break;
			case "^":
				valueStack.push(Math.pow(a, b));
				break;
		}
	}

	/**
	 * Getter method that checks if an identifier exists
	 * @param name		the name of the identifier to verify
	 * @return			value of identifier if found, 0.0 otherwise
	 */
	private double getIdentifierValue(String name) {
		for (Identifier id : identifiers) {
			if (id.getName().equals(name))
				return id.getValue();
		}
		return 0.0;
	}

	/**
	 * Setter method that stores or update an identifier value
	 *
	 * @param name		the name of the identifier
	 * @param value		the value of the identifier
	 */
	private void setIdentifier(String name, double value) {
		for (Identifier id : identifiers) {
			if (id.getName().equals(name)) {
				id.setValue(value);
				return;
			}
		}
		identifiers.add(new Identifier(name, value));
	}

	/**
	 * Checks if the name of the identifier is a valid name (contains only letters)
	 * @param name		the name of the identifier to check
	 * @return			true if identifier is a valid name, false otherwise
	 */
	public boolean isValidIdentifier(String name) {
		if (name.isEmpty())
			return false;
		for (int i = 0; i < name.length(); i++) {
			if (!Character.isLetter(name.charAt(i)))
				return false;
		}
		return true;
	}

	/**
	 * Precedence of operators
	 *
	 * @param op1 operator 1
	 * @param op2 operator 2
	 * @return true if op2 has higher or same precedence as op1; false otherwise
	 * Algorithm:
	 * if op1 is exponent, then false
	 * if op2 is either left or right parenthesis, then false
	 * if op1 is multiplication or division or modulus and
	 * op2 is addition or subtraction, then false
	 * otherwise true
	 */
	private boolean hasPrecedence(String op1, String op2) {
		if (op1.equals("^")) return false;
		if (op2.equals("(") || op2.equals(")")) return false;
		return (!op1.equals("*") && !op1.equals("/") && !op1.equals("%"))
                || (!op2.equals("+") && !op2.equals("-"));
    }
}
