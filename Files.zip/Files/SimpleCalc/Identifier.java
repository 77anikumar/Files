/**
 * Handles all identifiers' names and values
 *
 * @author Ani Kumar
 * @since March 3, 2025
 */
public class Identifier {
    private String name;	// identifier name
    private double value;	// identifier value

    /* Constructor that initializes fields */
    public Identifier(String name, double value) {
        this.name = name;
        this.value = value;
    }

    /* Getter method that returns identifier name */
    public String getName() {
        return name;
    }

    /* Getter method that returns identifier value */
    public double getValue() {
        return value;
    }

    /**
     * Setter method that sets passed identifier value to field variable
     *
     * @param v     value to set to field variable
     */
    public void setValue(double v) {
        value = v;
    }
}