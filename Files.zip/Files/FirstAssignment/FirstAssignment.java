/**
 *	FirstAssignment.java
 *	Display a brief description of your summer vacation on the screen.
 *
 *	To compile Linux:	javac -cp .:mvAcm.jar FirstAssignment.java
 *	To execute Linux:	java -cp .:mvAcm.jar FirstAssignment
 *
 *	To compile MS Powershell:	javac -cp ".;mvAcm.jar" FirstAssignment.java
 *	To execute MS Powershell:	java -cp ".;mvAcm.jar" FirstAssignment
 *
 *	@author	Ani Kumar
 *	@since	August 23, 2024
 */
import java.awt.Font;

import acm.program.GraphicsProgram;
import acm.graphics.GLabel;

public class FirstAssignment extends GraphicsProgram {
    
    public void run() {
    	//	The font to be used
    	Font f = new Font("Serif", Font.BOLD, 18);
    	
    	//	Line 1
    	GLabel s1 = new GLabel("What I did on my summer vacation ...", 10, 20);
    	s1.setFont(f);
    	add(s1);
    	
    	//	Line 2...
    	GLabel s2 = new GLabel("In June I flew to Ireland and stayed in both Galway and Dublin. I saw the", 10, 40);
    	s2.setFont(f);
    	add(s2);
    	GLabel s3 = new GLabel("Cliffs of Moher and had an Irish beef stew in a pub. Then I flew to Portugal and", 10, 60);
    	s3.setFont(f);
    	add(s3);
    	GLabel s4 = new GLabel("stayed in both Lisbon and Porto. I visited a few enormous cathedrals and castles", 10, 80);
    	s4.setFont(f);
    	add(s4);
    	GLabel s5 = new GLabel("and ate Pastel de nata, a famous Portugal dessert. That was the end of my Europe trip.", 10, 100);
    	s5.setFont(f);
    	add(s5);
    	GLabel s6 = new GLabel("A few days after I got back home, I went to the Advanced Space Academy program at the", 10, 120);
    	s6.setFont(f);
    	add(s6);
    	GLabel s7 = new GLabel("US Space & Rockets Center in Huntsville, Alabama. Throughout this week-long program, I", 10, 140);
    	s7.setFont(f);
    	add(s7);
    	GLabel s8 = new GLabel("took part in astronaut exercises and completed various engineering challenges with", 10, 160);
    	s8.setFont(f);
    	add(s8);
    	GLabel s9 = new GLabel("my team. We built heat shields and rovers. We also designed and flew our own rocket,", 10, 180);
    	s9.setFont(f);
    	add(s9);
    	GLabel s10 = new GLabel("successfully recovering the payload. But the highlight of the week was our simulated,", 10, 200);
    	s10.setFont(f);
    	add(s10);
    	GLabel s11 = new GLabel("NASA-style Space Shutle missions. I was appointed Commander for 1 of the 3 missions and", 10, 220);
    	s11.setFont(f);
    	add(s11);
    	GLabel s12 = new GLabel("(in the sim) flew and landed the Space Shuttle in Kennedy Space Center. We also got to do", 10, 240);
    	s12.setFont(f);
    	add(s12);
    	GLabel s13 = new GLabel("ziplining and numerous climbing activities, which were scary but thrilling experiences.", 10, 260);
    	s13.setFont(f);
    	add(s13);
    	GLabel s14 = new GLabel("After a demanding yet exhilarating week, I flew back home and focused on my AP statistics", 10, 280);
    	s14.setFont(f);
    	add(s14);
    	GLabel s15 = new GLabel("course, AP chemistry tutoring, and writing college essays, as application due dates were soon.", 10, 300);
    	s15.setFont(f);
    	add(s15);
    	
    	//	...Line 15
    	GLabel s16 = new GLabel("I focused on UC essays and my Personal Statement, working with my college counselor.", 10, 320);
    	s16.setFont(f);
    	add(s16);
    }
}
