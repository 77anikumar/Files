/**
 *	The game of Pig.
 *	Two players try to reach 100 points. In each turn, the player either
 *	rolls the die or holds and scores the sum of the turn. The user plays
 *	against the computer. The computer always holds when reaching 20 points.
 *
 *	@author	Ani Kumar
 *	@since	September 13, 2024
 */
public class PigGame {
    private int playerTotalScore, compTotalScore;
	private final int HOLD_AT, MAX_SCORE, LOSE_SCORE;
	Dice dice;
	
	/** Main method that executes the program */
	public static void main(String[] args) {
		PigGame piggame = new PigGame();
		piggame.runner();
	}

	/** Constructor that initializes field variables/constants */
	public PigGame() {
		dice = new Dice();
		playerTotalScore = compTotalScore = 0;
		HOLD_AT = 20;
		MAX_SCORE = 100;
		LOSE_SCORE = 1;
	}
	
	/** Runner method that calls other methods */
	public void runner() {
		printIntroduction();
		chooseGame();
	}

	/**	Print the introduction to the game */
	public void printIntroduction() {
		System.out.println("\n");
		System.out.println("______ _         _____");
		System.out.println("| ___ (_)       |  __ \\");
		System.out.println("| |_/ /_  __ _  | |  \\/ __ _ _ __ ___   ___");
		System.out.println("|  __/| |/ _` | | | __ / _` | '_ ` _ \\ / _ \\");
		System.out.println("| |   | | (_| | | |_\\ \\ (_| | | | | | |  __/");
		System.out.println("\\_|   |_|\\__, |  \\____/\\__,_|_| |_| |_|\\___|");
		System.out.println("          __/ |");
		System.out.println("         |___/");
		System.out.println("\nThe Pig Game is human vs computer. Each takes a"
				+ " turn rolling a die and the first to score");
		System.out.println("100 points wins. A player can either ROLL or "
				+ "HOLD. A turn works this way:");
		System.out.println("\n\tROLL:\t2 through 6: add points to turn total, "
				+ "player's turn continues");
		System.out.println("\t\t1: player loses turn");
		System.out.println("\tHOLD:\tturn total is added to player's score, "
				+ "turn goes to other player");
		System.out.println("\n");
	}
	
	/** Prompts the user to choose one of two games */
	public void chooseGame() {
		char c = Prompt.getChar("Play game or Statistics (p or s)");
		if (c == 'p')
			playGame();
		else if (c == 's')
			playStatistics();
		else
			chooseGame();
	}

	/**	Alternates between player and computer */
	public void playGame() {
		while (playerTotalScore < MAX_SCORE && compTotalScore < MAX_SCORE) {
			player();
			computer();
		}
	}

	/**	Handles player game functions, keeps
	 *	track of score, and checks if they win */
	public void player() {
        int playerTurnScore = 0;
		boolean onTurn = true;
		System.out.println("\n**** USER Turn ***");
		while (onTurn) {
			System.out.printf("\n%-18s%d\n", "Your turn score:", playerTurnScore);
			System.out.printf("%-18s%d\n", "Your total score:", playerTotalScore);
			char c = Prompt.getChar("(r)oll or (h)old");
			if (c == 'r') {
				System.out.println("\nYou ROLL");
				playerTurnScore += dice.roll();
				dice.printDice();
				if (dice.getValue() == LOSE_SCORE) {
					System.out.println("\nYou LOSE your turn.");
					System.out.printf("%-18s%d\n\n", "Your total score:", playerTotalScore);
					onTurn = false;

				}
			} else if (c == 'h') {
				System.out.println("\nYou HOLD");
				playerTotalScore += playerTurnScore;
				System.out.printf("%-18s%d\n\n", "Your total score:", playerTotalScore);
				if (playerTotalScore >= MAX_SCORE) {
					playerWinGame();
				}
				onTurn = false;
			}
		}
	}

	/**	Handles computer game functions, keeps
	 *	track of score, and checks if it wins */
	public void computer() {
        int compTurnScore = 0;
		boolean onTurn = true;
		System.out.println("\n**** COMPUTER'S Turn ***");
		while (onTurn) {
			System.out.printf("\n%-22s%d\n", "Computer turn score:", compTurnScore);
			System.out.printf("%-22s%d\n", "Computer total score:", compTotalScore);
			Prompt.getString("Press enter for computer's turn");
			if (compTurnScore >= HOLD_AT) {
				System.out.println("\nComputer will HOLD");
				compTotalScore += compTurnScore;
				System.out.printf("%-22s%d\n", "Computer total score:", compTotalScore);
				if (compTotalScore >= MAX_SCORE) {
					compWinGame();
				}
				onTurn = false;
			} else {
				compTurnScore += dice.roll();
				if (compTotalScore + compTurnScore >= MAX_SCORE) {
					System.out.println("\nComputer will HOLD");
					System.out.printf("%-22s%d\n", "Computer total score:", compTotalScore + compTurnScore);
					compWinGame();
				}
				System.out.println("\nComputer will ROLL");
				dice.printDice();
				if (dice.getValue() == LOSE_SCORE) {
					System.out.println("\nComputer loses turn.");
					System.out.printf("%-22s%d\n", "Computer total score:", compTotalScore);
					onTurn = false;
				}
			}
		}
	}

	/**	Prints player win message and exits game */
	public void playerWinGame() {
		System.out.print("Congratulations!!! YOU WON!!!!\n\n");
		System.out.print("Thanks for playing the Pig Game!!!\n");
		System.exit(0);
	}

	/**	Prints computer win message and exits game */
	public void compWinGame() {
		System.out.print("Too bad. COMPUTER WON.\n\n");
		System.out.print("Thanks for playing the Pig Game!!!\n");
		System.exit(0);
	}

	/**	Prompts user for number of turns to run then
	 * calculates probability for 0 and 20 to 25 */
	public void playStatistics() {
		int[] pointCount = new int[7];
		double probZero, prob;
		System.out.print("\nRun statistical analysis - \"Hold at 20\"\n\n");
		int numTurns = Prompt.getInt("Number of turns", 1000, 10000000);
		for (int i = 0; i < numTurns; i++) {
			int score = runAnalysis();
			if (score == 0)
				pointCount[0]++;
			else
				pointCount[score - 19]++;
		}
		System.out.printf("\n%-12s%s\n", "Score", "Estimated Probability");
		probZero = (double) pointCount[0] / numTurns;
		System.out.printf("%-12d%.6f\n", 0, probZero);
		for (int i = 20; i < 26; i++) {
			prob = (double) pointCount[i - 19] / numTurns;
			System.out.printf("%-12d%.6f\n", i, prob);
		}
	}

	/**	Rolls dice until computer turne ends */
	public int runAnalysis() {
		int compTurnScore = 0;
		while (true) {
			int val = dice.roll();
			if (val == LOSE_SCORE) // comp loses turn so 0 points are scored
				return 0;
			else {
				compTurnScore += val;
				if (compTurnScore >= HOLD_AT)
					return compTurnScore;
			}
		}
	}
}