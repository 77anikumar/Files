/**
 *	The game of Pig.
 *	Two players try to reach 100 points. In each turn, the player either
 *	rolls the die or holds and scores the sum of the turn. The user plays
 *	against the computer. The computer always holds when reaching 20 points.
 *
 *	@author	Ani Kumar
 *	@since	September 13, 2024
 */
public class PigGame {
	private final int playerTurnScore, playerTotalScore;
	private final int compTurnScore, compTotalScore;
	private final int HOLD_AT, MAX_SCORE;
	
	/** Main method that executes the program */
	public static void main(String[] args) {
		PigGame piggame = new PigGame();
		piggame.runner();
	}
	
	public PigGame() {
		playerTurnScore = playerTotalScore = 0;
		compTurnScore = compTotalScore = 0;
		HOLD_AT = 20;
		MAX_SCORE = 100;
	}
	
	/** Runner method that calls other methods */
	public void runner() {
		printIntroduction();
		chooseGame();
	}
	
	/** Prompts the user to choose one of two games */
	public void chooseGame() {
		char c = Prompt.getChar("Play game or Statistics (p or s)");
		if (c == 'p')
			playGame();
		else if (c == 's')
			playStatistics();
		else
			chooseGame();
	}

	public void playGame() {
		while (playerTotalScore < MAX_SCORE && compTotalScore < MAX_SCORE) {
			player();
			if (playerTotalScore >= MAX_SCORE)
				break;
			computer();
			if (compTotalScore >= MAX_SCORE)
				break;
		}
	}
	
	public void player() {
		boolean onTurn = true;
					
		System.out.println("**** USER Turn ***");
		while (onTurn) {
			System.out.printf("\n%-18s%d\n", "Your turn score:", playerTurnScore);
			System.out.printf("%-18s%d\n\n", "Your total score:", playerTotalScore);
			char c = Prompt.getChar("(r)oll or (h)old");
			if (c == 'r') {
				Dice.roll();
			} else if (c == 'h') {
				System.out.println("Holding");
			}
		}
	}
		
	public void playStatistics() {}
	
	/**	Print the introduction to the game */
	public void printIntroduction() {
		System.out.println("\n");
		System.out.println("______ _         _____");
		System.out.println("| ___ (_)       |  __ \\");
		System.out.println("| |_/ /_  __ _  | |  \\/ __ _ _ __ ___   ___");
		System.out.println("|  __/| |/ _` | | | __ / _` | '_ ` _ \\ / _ \\");
		System.out.println("| |   | | (_| | | |_\\ \\ (_| | | | | | |  __/");
		System.out.println("\\_|   |_|\\__, |  \\____/\\__,_|_| |_| |_|\\___|");
		System.out.println("          __/ |");
		System.out.println("         |___/");
		System.out.println("\nThe Pig Game is human vs computer. Each takes a"
							+ " turn rolling a die and the first to score");
		System.out.println("100 points wins. A player can either ROLL or "
							+ "HOLD. A turn works this way:");
		System.out.println("\n\tROLL:\t2 through 6: add points to turn total, "
							+ "player's turn continues");
		System.out.println("\t\t1: player loses turn");
		System.out.println("\tHOLD:\tturn total is added to player's score, "
							+ "turn goes to other player");
		System.out.println("\n");	
	}
}
