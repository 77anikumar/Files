import java.util.ArrayList;
import java.util.Scanner;

/**
 *	Provides important methods for AnagramMaker.
 *
 *	Requires the FileUtils and Prompt classes.
 *
 *	@author	Ani Kumar
 *  @since	January 17, 2025
 */
public class WordUtilities {
    private ArrayList<String> words;	// dictionary of words
    private Scanner scanner;            // scanner for file

    /* Constructor that initializes fields */
    public WordUtilities() {
        words = new ArrayList<>();
    }

    /* Scans text file and adds words to List */
    public void readWordsFromFile(String fileName) {
        String word;
        int count = 0;
        scanner = FileUtils.openToRead(fileName);
        while(scanner.hasNextLine()) {
            word = scanner.nextLine();
            words.add(count, word);
            count++;
        }
    }

    /**
     *	Determines if a word's characters match a group of letters
     *	@param word		the word to check
     *	@param letters	the letters
     *	@return			true if the word's chars match; false otherwise
     */
    private boolean wordMatch(String word, String letters) {
        // if the word is longer than letters return false
        if (word.length() > letters.length()) return false;
        // while there are still characters in word, check each word character
        // with letters
        while (!word.isEmpty()) {
            // using the first character in word, find the character's index inside letters
            // and ignore the case
            int index = letters.toLowerCase().indexOf(Character.toLowerCase(word.charAt(0)));
            // if the word character is not in letters, then return false
            if (index < 0) return false;

            // remove character from word and letters
            word = word.substring(1);
            letters = letters.substring(0, index) + letters.substring(index + 1);
        }
        // all word letters were found in letters
        return true;
    }

    /**
     *	finds all words that match some or all of a group of alphabetic characters
     *	Precondition: letters can only contain alphabetic characters a-z and A-Z
     *	@param letters		group of alphabetic characters
     *	@return				an ArrayList of all the words that match some or all
     *						of the characters in letters
     */
    public ArrayList<String> allWords(String letters) {
        ArrayList<String> wordsFound = new ArrayList<>();
        // check each word in the database with the letters
        for (String word: words)
            if (wordMatch(word, letters))
                wordsFound.add(word);
        return wordsFound;
    }

    /* Sort the words in the database */
    public void sortWords() {
        SortMethods sm = new SortMethods();
        sm.mergeSort(words);
    }

    /**
     * Removes chars of phrase from original word and returns remaining chars
     * @param originalWord	original word
     * @param phrase        phrase to be removed
     * @return String       the remaining word to be checked
     */
    public String removeWord(String originalWord, String phrase) {
        String remainingWord = "";
        boolean[] charIsFound = new boolean[originalWord.length()];
        for (int i = 0; i < phrase.length(); i++) {
            char c = phrase.charAt(i);
            for (int j = 0; j < originalWord.length(); j++) {
                if (c == originalWord.charAt(j) && !charIsFound[j]) {
                    charIsFound[j] = true;
                    break;
                }
            }
        }
        for (int i = 0; i < originalWord.length(); i++) {
            if (!charIsFound[i])
                remainingWord += originalWord.charAt(i);
        }
        return remainingWord;
    }
}