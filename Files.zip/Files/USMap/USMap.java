/**
 *	USMap.java
 *	Creating a map of US cities from text files using StdDraw
 *
 *	@author	Ani Kumar
 *	@since	September 4, 2024
 */

import java.util.Scanner;

public class USMap {
    public static void main(String[] args) {
        USMap map = new USMap();
        map.setupCanvas();
    }
    
    public void setupCanvas() {
        StdDraw.setTitle("USMap");
        StdDraw.setCanvasSize(900, 512);
        StdDraw.setXscale(128.0, 65.0);
        StdDraw.setYscale(22.0, 52.0);
        runner();
    }
    
    public void runner() {
        double[] x = new double[1112];
        double[] y = new double[1112];
        String[] cities = new String[1112];
        String[] bigCitiesInfo = new String[275];
        int[] populationInfo = new int[275];
        Scanner citiesScanner = FileUtils.openToRead("cities.txt");
        Scanner bigCitiesScanner = FileUtils.openToRead("bigCities.txt");
        Scanner bigCitiesPopScanner = FileUtils.openToRead("bigCities.txt");

        for (int i = 0; i < 1112; i++) { // cities
            y[i] = citiesScanner.nextDouble();
            x[i] = citiesScanner.nextDouble();
            cities[i] = citiesScanner.nextLine();
        }

        for (int i = 0; i < 275; i++) { // big cities
            bigCitiesScanner.next();
            bigCitiesInfo[i] = bigCitiesScanner.nextLine();
        }

        for (int c = 0; c < 275; c++) { // population
            do {
                bigCitiesPopScanner.next();
            } while (!bigCitiesPopScanner.hasNextInt());
            populationInfo[c] = bigCitiesPopScanner.nextInt();
            bigCitiesPopScanner.nextLine();
        }

        // confirming no duplicates in big cities
        String[] checkForDuplicates = new String[275];
        boolean noDuplicates;
        for (int a = 0; a < 275; a++) {
            for (int b = 0; b < 1112; b++) {
                if (bigCitiesInfo[a].contains(cities[b])) {
                    noDuplicates = true;
                    for (int c = 0; c < b; c++) {
                        if (cities[b].equals(cities[c])) {
                            noDuplicates = false;
                            break; // counts only one in the instance that duplicates are found
                        }
                    }
                    if (noDuplicates) {
                        checkForDuplicates[a] = cities[b];
                    }
                }
            }
        }

        String[] bigCities = new String[120];
        int[] population = new int[120];
        int p = 0;
        for (int a = 0; a < 275; a++) {
            if (checkForDuplicates[a] == null) {
                a++;
            } else {
                bigCities[p] = checkForDuplicates[a];
                population[p] = populationInfo[a];
                p++;
            }
        }

        // coordinates
        double[] xBig = new double[120];
        double[] yBig = new double[120];
        for (int i = 0; i < 120; i++) {
            for (int j = 0; j < 1112; j++) {
                if (bigCities[i].equals(cities[j])) {
                    yBig[i] = y[j];
                    xBig[i] = x[j];
                }
            }
        }

        for (int b = 0; b < 120; b++) { // big cities
            StdDraw.setPenRadius(0.6 * (Math.sqrt(population[b]) / 18500));
            if (b < 10) { // 10 largest cities
                StdDraw.setPenColor(StdDraw.RED);
            } else { // other big cities
                StdDraw.setPenColor(StdDraw.BLUE);
            }
            StdDraw.point(xBig[b], yBig[b]);
        }
        
        for (int c = 0; c < 1112; c++) { // cities
            StdDraw.setPenRadius(0.006);
            StdDraw.setPenColor(StdDraw.DARK_GRAY);
            StdDraw.point(x[c], y[c]);
        }
    }
}