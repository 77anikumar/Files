import java.util.HashMap;

/**
 *  This class creates and manages one array of pegs from the game MasterMind.
 *
 *  @author	Ani Kumar
 *  @since	September 27, 2024
*/
public class PegArray {
	private Peg[] pegs;	// array of pegs
	Dice dice;			// instance of Dice class

	// the number of exact and partial matches for this array
	// as matched against the master.
	// Precondition: these values are valid after getExactMatches() and getPartialMatches()
	// are called
	private int exactMatches, partialMatches;
		
	/**
	 *	Constructor
	 *	@param numPegs	number of pegs in the array
	 */
	public PegArray(int numPegs) {
		pegs = new Peg[numPegs];
		for (int i = 0; i < pegs.length; i++) {
			pegs[i] = new Peg();
		}
		dice = new Dice();
		exactMatches = partialMatches = 0;
	}

	/** Test code for manually setting master code */
	public PegArray(String pc) {
		pegs = new Peg[pc.length()];
		for (int i = 0; i < pegs.length; i++) {
			pegs[i] = new Peg(pc.charAt(i));
		}
	}

	/** Randomly generates and stores master code */
	public void populateRandom() {
        for (Peg peg : pegs) {
            int val = dice.roll();
            peg.setLetter((char) (64 + val));
        }
	}

	/** getter for array of pegs */
	public Peg[] getPegArray() {
		return pegs;
	}

	/**
	 *	Return the peg object
	 *	@param n	The peg index into the array
	 *	@return		the peg object
	 */
	public Peg getPeg(int n) {
		return pegs[n];
	}

	/** If user input char is an exact or partial match to master code,
	 * decrements that char's counter in the master HashMap. If counter
	 * becomes 0, removes that char from the HashMap.
	 * @param c				The matched character
	 * @param masterHash	The HashMap of master code chars
	 */
	private void decrementHashCount(char c, HashMap<Character, Integer> masterHash) {
		if (!masterHash.containsKey(c)) {
			return;
		}
		int val = masterHash.get(c);
		val--;
		if (val == 0) {
			masterHash.remove(c);
		} else {
			masterHash.put(c, val);
		}
	}

	/**
	 *  Finds exact matches between master (key) peg array and this peg array
	 *	Postcondition: field exactMatches contains the matches with the master
	 *  @param master		The master (code) peg array
 	 * 	@param masterHash	The HashMap of master code chars
	 *	@return				The number of exact matches
	 */
	public int getExactMatches(PegArray master, HashMap<Character, Integer> masterHash) {
		exactMatches = 0;  // reset counter for each guess
		for (int i = 0; i < pegs.length; i++) {
			char c = pegs[i].getLetter();
			if (c == master.getPeg(i).getLetter()) {  // compare letters in each peg
				exactMatches++;
				decrementHashCount(c, masterHash);
			}
		}
		return exactMatches;
	}

	/**
	 *  Find partial matches between master (key) peg array and this peg array
	 *	Postcondition: field partialMatches contains the matches with the master
	 *  @param master		The master (code) peg array
	 *  @param masterHash	The HashMap of master code chars
	 */
	public int getPartialMatches(PegArray master, HashMap<Character, Integer> masterHash) {
		partialMatches = 0;  // reset counter for each guess
		for (int i = 0; i < pegs.length; i++) {
			char c = pegs[i].getLetter();
			if (masterHash.containsKey(c) && c != master.getPeg(i).getLetter()) {
				partialMatches++;
				decrementHashCount(c, masterHash);
			}
		}
		return partialMatches;
	}
	
	// Accessor methods
	// Precondition: getExactMatches() and getPartialMatches() must be called first
	public int getExact() {
		return exactMatches;
	}
	
	public int getPartial() {
		return partialMatches;
	}
}
