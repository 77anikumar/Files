import java.io.PrintWriter; import java.util.Scanner;

/**
 *	MVCipher - The user inputs a keyword (>=3 chars and only letters)
 *	and this encrypts or decrypts a text file.
 *	Requires Prompt and FileUtils classes.
 *	
 *	@author	Ani Kumar
 *	@since	September 20, 2024
 */
public class MVCipher {
	private final int NUM_LETTERS, ASCII_VAL, LOWER_A, LOWER_Z, UPPER_A, UPPER_Z;
	private char[] keyLetters;
	
	/** Constructor that initializes variables and constants */
	public MVCipher() {
		NUM_LETTERS = 26;
		ASCII_VAL = 64;
		LOWER_A = 97;
		LOWER_Z = 122;
		UPPER_A = 65;
		UPPER_Z = 90;
	}
	/** Main that executes the program */
	public static void main(String[] args) {
		MVCipher mvc = new MVCipher();
		mvc.run();
	}
	
	/** Runner method that takes valid input and creates respective file */
	public void run() {
		/* Prompt for a key and change to uppercase
		   Do not let the key contain anything but alpha
		   Use the Prompt class to get user input */
		String key = "";
		boolean worked = false;
		while (!worked) {
			String word = Prompt.getString("Please input a word to use as key (letters only)");
			if (word.length() >= 3) {
				boolean redo = false;
				for (int i = 0; i < word.length(); i++) {
					if (!Character.isLetter(word.charAt(i))) {
						redo = true;
						worked = false;
					}
				}
				if (!redo)
					worked = true;
			} else
				worked = false;
			if (!worked)
				System.out.println("ERROR: Key must be all letters and at least 3 characters long");
			else {
				key = word.toUpperCase();
				keyLetters = key.toCharArray();
			}
		}
		/* Prompt for encrypt or decrypt */
		int crypt = Prompt.getInt("Encrypt or decrypt?", 1, 2);
			
		/* Prompt for an input file name */
		String inFile = "";
		if (crypt == 1)
			inFile = Prompt.getString("Name of file to encrypt");
		else
			inFile = Prompt.getString("Name of file to decrypt");
		Scanner checkIfExists = FileUtils.openToRead(inFile);
		checkIfExists.close();
		
		/* Prompt for an output file name */
		String outFile = Prompt.getString("Name of output file");
		
		/* Read input file, encrypt or decrypt, and print to output file */
		if (crypt == 1) {
			System.out.println("The encrypted file " + outFile + " has been created using the keyword -> " + key);
			this.encrypt(inFile, outFile);
		} else {
			System.out.println("The decrypted file " + outFile + " has been created using the keyword -> " + key);
			this.decrypt(inFile, outFile);
		}
	}
	
	/**
	 * Uses keyword to encrypt file
	 * @param inFile  name of the file to read
	 * @param outFile name of the file to write
	 */
	public void encrypt(String inFile, String outFile) {
		Scanner reader = FileUtils.openToRead(inFile);
		PrintWriter writeFile = FileUtils.openToWrite(outFile);
		int numLetters = 0;
		while (reader.hasNext()) {
			String nextLine = reader.nextLine();
			for (int i = 0; i < nextLine.length(); i++) {
				char c = nextLine.charAt(i);
				if (c >= 'A' && c <= 'Z')  {
					c = (char)(c + keyLetters[numLetters] - ASCII_VAL);
					if (c > UPPER_Z) {
						c = (char)(c - NUM_LETTERS);
					}
					numLetters++;
					if (numLetters >= keyLetters.length)
						numLetters = 0;
				}
				if (c >= 'a' && c <= 'z') {
					c = (char)(c + keyLetters[numLetters] - ASCII_VAL);
					if (c > LOWER_Z)
						c = (char)(c - NUM_LETTERS);
					numLetters++;
					if (numLetters >= keyLetters.length)
						numLetters = 0;
				}
				writeFile.print(c);
			}
			writeFile.print("\n");
		}
		writeFile.close();
	}
	
	/**
	 * Uses keyword to decrypt file
	 * @param inFile  name of the file to read
	 * @param outFile name of the file to write
	 */
	public void decrypt(String inFile, String outFile) {
		Scanner reader = FileUtils.openToRead(inFile);
		PrintWriter writeFile = FileUtils.openToWrite(outFile);
		int numLetters = 0;
		while (reader.hasNext()) {
			String nextLine = reader.nextLine();
			for (int i = 0; i < nextLine.length(); i++) {
				char c = nextLine.charAt(i);
				if (c >= 'A' && c <= 'Z') {
					c = (char)(c - keyLetters[numLetters] + ASCII_VAL);
					if (c < UPPER_A) {
						c = (char)(c + NUM_LETTERS);
					}
					numLetters++;
					if (numLetters >= keyLetters.length)
						numLetters = 0;
				}
				if (c >= 'a' && c <= 'z') {
					c = (char)(c - keyLetters[numLetters] + ASCII_VAL);
					if (c < LOWER_A)
						c = (char)(c + NUM_LETTERS);
					numLetters++;
					if (numLetters >= keyLetters.length)
						numLetters = 0;
				}
				writeFile.print(c);
			}
			writeFile.print("\n");
		}
		writeFile.close();
	}
}
