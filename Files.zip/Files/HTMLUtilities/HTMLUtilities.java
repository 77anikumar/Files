/**
 *	Utilities for handling HTML
 *
 *	@author	Ani Kumar
 *	@since	November 1, 2024
 */
public class HTMLUtilities {
	private enum TokenState { NONE, COMMENT, PREFORMAT } // NONE = not nested in a block,
	// COMMENT = inside a comment block, // PREFORMAT = inside a pre-format block
	private TokenState state; // the current tokenizer state
	private final int COMMENT_TAG_LENGTH = 3;
	private final int PREFORMAT_TAG_LENGTH = 5;
	private final int PREFORMAT_SL_TAG_LENGTH = 6;

	/**
	 *	Break the HTML string into tokens. The array returned is
	 *	exactly the size of the number of tokens in the HTML string.
	 *	Example:	HTML string = "Goodnight moon goodnight stars"
	 *				returns { "Goodnight", "moon", "goodnight", "stars" }
	 *	@param str			the HTML string
	 *	@return				the String array of tokens
	 */
	public String[] tokenizeHTMLString(String str) {
		String[] tokens = new String[10000];
		int tokenCounter = 0;
		int i = 0;
		if (state == null)
			state = TokenState.NONE;
		while (i < str.length()) {
			char c = str.charAt(i);
			if (state == TokenState.NONE && Character.isWhitespace(c)) {
				while (i < str.length() && Character.isWhitespace(str.charAt(i))) {
					i++;
				}
				continue;
			}
			// Part 2 functions
			// 1. Entering comment block?
			if (state == TokenState.NONE && str.startsWith("<!--", i)) {
				state = TokenState.COMMENT;
				i = str.indexOf("-->", i) + COMMENT_TAG_LENGTH;
				if (i < COMMENT_TAG_LENGTH)
					i = str.length();
				continue;
			}
			if (state == TokenState.COMMENT && str.startsWith("-->", i)) {
				state = TokenState.NONE;
				i += COMMENT_TAG_LENGTH;
				continue;
			}
			if (state == TokenState.COMMENT) {
				i++;
				continue;
			}
			// 2. Entering/exiting preformatted block?
			if (state == TokenState.NONE && str.startsWith("<pre>", i)) {
				state = TokenState.PREFORMAT;
				tokens[tokenCounter++] = "<pre>";
				i += PREFORMAT_TAG_LENGTH;
				continue;
			}
			if (state == TokenState.PREFORMAT && str.startsWith("</pre>", i)) {
				state = TokenState.NONE;
				tokens[tokenCounter++] = "</pre>";
				i += PREFORMAT_SL_TAG_LENGTH;
				continue;
			}
			if (state == TokenState.PREFORMAT) { // So whitespace isn't trimmed
				int preEnd = str.indexOf("</pre>", i);
				if (preEnd == -1)
					preEnd = str.length(); // If closing tag isn't found, set to end of string
				tokens[tokenCounter++] = str.substring(i, preEnd); // Adds string content as it is
				i = preEnd;
				state = TokenState.NONE;
				continue;
			}
			// Part 1 functions
			// 1. tags
			if (c == '<') {
				int tagEnd = str.indexOf('>', i);
				if (tagEnd != -1) {
					tokens[tokenCounter++] = str.substring(i, tagEnd + 1);
					i = tagEnd + 1;
					continue;
				}
			}
			// 2. words
			if (Character.isLetter(c)) {
				int startOfWord = i;
				while (i < str.length() && (Character.isLetter(str.charAt(i)) ||
						(str.charAt(i) == '-' && i + 1 < str.length() && Character.isLetter(str.charAt(i + 1))))) {
					i++;
				}
				tokens[tokenCounter++] = str.substring(startOfWord, i);
				continue;
			}
			// 3. numbers
			if (Character.isDigit(c) || (c == '-' && i + 1 < str.length() && Character.isDigit(str.charAt(i + 1)))) {
				int numStart = i;
				boolean containsDecimalPt = false;
				boolean containsExponentE = false;
				i++;
				while (i < str.length() && (Character.isDigit(str.charAt(i)) ||
						(str.charAt(i) == '.' && !containsDecimalPt) ||
						(str.charAt(i) == 'e' || str.charAt(i) == 'E' && !containsExponentE) ||
						(str.charAt(i) == '-' && (str.charAt(i - 1) == 'e' || str.charAt(i - 1) == 'E')))) {
					if (str.charAt(i) == '.')
						containsDecimalPt = true;
					if (str.charAt(i) == 'e' || str.charAt(i) == 'E')
						containsExponentE = true;
					i++;
				}
				tokens[tokenCounter++] = str.substring(numStart, i);
				continue;
			}
			// 4. punctuation
			if (isPunct(c)) {
				tokens[tokenCounter++] = String.valueOf(c);
				i++;
				continue;
			}
			i++; // next char
		}
		String[] result = new String[tokenCounter];
		System.arraycopy(tokens, 0, result, 0, tokenCounter);
		return result;
	}

	/**
	 * Helper method to identify if a char is punctuation.
	 *
	 * @param c 			the character to check
	 * @return true if c is some kind of punctuation char
	 */
	private boolean isPunct(char c) {
		return ". , ; : ( ) ? ! ~ & = - +".indexOf(c) != -1;
	}

	/**
	 *	Print the tokens in the array to the screen
	 *	Precondition: All elements in the array are valid String objects.
	 *				(no nulls)
	 *	@param tokens		an array of String tokens
	 */
	public void printTokens(String[] tokens) {
		if (tokens == null)
			return;
		for (int a = 0; a < tokens.length; a++) {
			if (a % 5 == 0)
				System.out.print("\n  ");
			System.out.print("[token " + a + "]: " + tokens[a] + " ");
		}
		System.out.println();
	}
}