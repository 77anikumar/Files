import java.util.NoSuchElementException;
import java.util.Objects;

/*
 *	SinglyLinkedList.
 *
 *	@author	Ani Kumar
 *	@since	April 28, 2025
 */
public class SinglyLinkedList<E extends Comparable<E>> {

	/* Fields */
	private ListNode<E> head, tail;	// head and tail pointers to list
	private int size;

	/* No-args Constructors */
	public SinglyLinkedList() {
		head = null;
		tail = null;
		size = 0;
	}

	/* Copy constructor */
	public SinglyLinkedList(SinglyLinkedList<E> oldList) {
		this();
		if (oldList != null && oldList.head != null) {
			ListNode<E> currentOld = oldList.head;
			head = new ListNode<>(currentOld.getValue());
			tail = head;
			size = 1;
			currentOld = currentOld.getNext();
			while (currentOld != null) {
				ListNode<E> newNode = new ListNode<>(currentOld.getValue());
				tail.setNext(newNode);
				tail = newNode;
				size++;
				currentOld = currentOld.getNext();
			}
		}
	}

	/* Clears the list of elements */
	public void clear() {
		head = null;
		tail = null;
		size = 0;
	}

	/**	Add the object to the end of the list
	 *	@param obj		the object to add
	 *	@return			true if successful; false otherwise
	 */
	public boolean add(E obj) {
		ListNode<E> newNode = new ListNode<>(obj);
		if (isEmpty()) {
			head = newNode;
			tail = newNode;
		} else {
			tail.setNext(newNode);
			tail = newNode;
		}
		size++;
		return true;
	}

	/**	Add the object at the specified index
	 *	@param index		the index to add the object
	 *	@param obj			the object to add
	 *	@return				true if successful; false otherwise
	 *	@throws NoSuchElementException if index does not exist
	 */
	public boolean add(int index, E obj) {
		if (index < 0 || index > size)
			throw new NoSuchElementException("Index: " + index + ", Size: " + size);
		ListNode<E> newNode = new ListNode<>(obj);
		if (index == 0) {
			newNode.setNext(head);
			head = newNode;
			if (tail == null)
				tail = newNode;
		} else if (index == size) {
			tail.setNext(newNode);
			tail = newNode;
		} else {
			ListNode<E> previous = getNodeAt(index - 1);
			newNode.setNext(previous.getNext());
			previous.setNext(newNode);
		}
		size++;
		return true;
	}

	/* @return the number of elements in this list */
	public int size() {
		return size;
	}

	/**	Return the ListNode at the specified index
	 *	@param index		the index of the ListNode
	 *	@return				the ListNode at the specified index
	 *	@throws NoSuchElementException if index does not exist
	 */
	public ListNode<E> get(int index) {
		return getNodeAt(index);
	}

	/**	Replace the object at the specified index
	 *	@param index		the index of the object
	 *	@param obj			the object that will replace the original
	 *	@return				the object that was replaced
	 *	@throws NoSuchElementException if index does not exist
	 */
	public E set(int index, E obj) {
		ListNode<E> node = getNodeAt(index);
		E originalValue = node.getValue();
		node.setValue(obj);
		return originalValue;
	}

	/**	Remove the element at the specified index
	 *	@param index		the index of the element
	 *	@return				the object in the element that was removed
	 *	@throws NoSuchElementException if index does not exist
	 */
	public E remove(int index) {
		if (isEmpty())
			throw new NoSuchElementException("Cannot remove from an empty list.");
		if (index < 0 || index >= size)
			throw new NoSuchElementException("Index: " + index + ", Size: " + size);
		E removedValue;
		if (index == 0) {
			removedValue = head.getValue();
			head = head.getNext();
			if (head == null)
				tail = null;
		} else {
			ListNode<E> previous = getNodeAt(index - 1);
			ListNode<E> current = previous.getNext();
			removedValue = current.getValue();
			previous.setNext(current.getNext());
			if (index == size - 1)
				tail = previous;
		}
		size--;
		return removedValue;
	}

	/* @return true if list is empty; false otherwise */
	public boolean isEmpty() {
		return size == 0;
	}

	/**	Tests whether the list contains the given object
	 *	@param object		the object to test
	 *	@return				true if the object is in the list; false otherwise
	 */
	public boolean contains(E object) {
		ListNode<E> current = head;
		while (current != null) {
			if (Objects.equals(current.getValue(), object))
				return true;
			current = current.getNext();
		}
		return false;
	}

	/**	Return the first index matching the element
	 *	@param element		the element to match
	 *	@return				if found, the index of the element; otherwise returns -1
	 */
	public int indexOf(E element) {
		ListNode<E> current = head;
		int index = 0;
		while (current != null) {
			if (Objects.equals(current.getValue(), element))
				return index;
			current = current.getNext();
			index++;
		}
		return -1;
	}

	/* Prints the list of elements */
	public void printList() {
		ListNode<E> current = head;
		while (current != null) {
			System.out.print(current.getValue() + (current.getNext() == null ? "" : "; "));
			current = current.getNext();
		}
		System.out.println();
	}

	/* Helper method to get the node at a specific index */
	private ListNode<E> getNodeAt(int index) {
		if (index < 0 || index >= size)
			throw new NoSuchElementException("Index: " + index + ", Size: " + size);
		ListNode<E> current = head;
		for (int i = 0; i < index; i++)
			current = current.getNext();
		return current;
	}
}