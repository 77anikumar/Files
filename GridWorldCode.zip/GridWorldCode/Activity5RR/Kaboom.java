/**
 * Defines the Kaboom actor.
 * 
 * @author	Ani Kumar
 * @since	March 28, 2025
 */

import info.gridworld.actor.Actor;
import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;

public class Kaboom extends Actor {
	private int lifetime;				// lifetime of Kaboom
	private final int threshold = 3;	// threshold constant
	
	public Kaboom() {
		setColor(null);
		lifetime = threshold;
	}
	
	/* Counts down actor's lifetime then removes itself from grid. */
	public void act() {
		lifetime--;
		if (lifetime == 0)
			removeSelfFromGrid();
	}
}
