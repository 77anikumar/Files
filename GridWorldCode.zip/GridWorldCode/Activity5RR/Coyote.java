/**
 * The Coyote drops Stones as he wanders around the grid. He moves in straight
 * lines, but stops every couple steps to drop a stone and change direction.
 * 
 * @author	Ani Kumar
 * @since	March 28, 2025
 */

import info.gridworld.actor.Actor;
import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;
import info.gridworld.actor.Critter;
import java.util.ArrayList;

public class Coyote extends Critter {
	
	// stores the 8 compass directions Coyote can move in
	private int[] dirs = { Location.NORTH, Location.NORTHEAST, 
				Location.EAST, Location.SOUTHEAST, Location.SOUTH, 
				Location.SOUTHWEST, Location.WEST, Location.NORTHWEST }
	private final int TIME = 5;		// how long Coyote walks or sleeps for
	private boolean isSleeping;		// indicates if Coyote is sleeping
	private boolean hasExploded;	// indicates if Coyote has exploded
	private boolean hasHitObst;		// indicates if Coyote has hit obstacle
	private int sleepLeft;			// number of remaining sleep cycles
	private int stepsLeft;			// number of remaining movement cycles
	
	public Coyote() {
		setColor(null);
		setDirection(dirs[(int)(Math.random() * 8)]);
		sleepLeft = stepsLeft = DURATION;
		isSleeping = hasExploded = hasHitObst = false;
	}
	
	public void makeMove(Location loc) {
		if (hasExploded)
			return;
		Grid grid = getGrid();
		if (!isSleeping) {
			if (grid.isValid(loc) == false || grid.get(loc) instanceof Actor) {
				stepsLeft = DURATION;
				hasBumped = true;
				isSleeping = true;				
			} else {
				moveTo(loc);
				stepsLeft--;
				if (stepsLeft == 0) {
					stepsLeft = DURATION;
					isSleeping = true;
				}
			}
		} else {
			sleepLeft--;
			if (sleepLeft == 0) {
				numSleepLeft = DURATION;
				isSleeping = false;
				ArrayList<Location> validLocs = getGrid().getValidAdjacentLocations(getLocation());
				Location randLoc = validLocs.get((int)(Math.random() * validLocs.size()));
				setDirection(getLocation().getDirectionToward(randLoc));
				if (!hasHitObst)
					putStone();
				hasHitObst = false;
			}
		}
	}
	
	public void putStone() {
		ArrayList<Location> locs = new ArrayList<Location>();
		for (int dir : dirs) {
			Location loc1 = getLocation().getAdjacentLocation(dir);
			if (getGrid().isValid(loc1) && getGrid().get(loc1) == null)
				locs.add(loc1);
		}
		if (locs.isEmpty())
			return;
		Location loc = locs.get((int)(Math.random() * locs.size()));
		Stone stone = new Stone();
		stone.putSelfInGrid(getGrid(), loc);
	}
}
