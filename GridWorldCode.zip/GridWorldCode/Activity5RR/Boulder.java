/**
 * Defines the Boulder actor.
 * 
 * @author	Ani Kumar
 * @since	March 28, 2025
 */

import info.gridworld.actor.Actor;
import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;
import java.awt.Color;
import java.util.Random;

public class Boulder extends Actor {
	private int lifetime;				// lifetime of Boulder
	private final int threshold = 3;	// determines when Boulder explodes
	
	public Boulder() {
		setColor(null);
		lifetime = (int)(Math.random() * 200 + 1);
	}
	
	public Boulder(int life) {
		setColor(null);
		lifetime = life;
	}
	
	/* Counts down actor's lifetime then replaces with Kaboom. */
	public void act() {
		lifetime--;
		if (lifetime < threshold && lifetime > 0)
			setColor(Color.RED);
		if (lifetime == 0) {
			removeSelfFromGrid();
			Kaboom kaboom = new Kaboom();
			kaboom.putSelfInGrid(getGrid(), getLocation())
			
		}
	}
}
