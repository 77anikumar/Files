import info.gridworld.actor.Actor;
import info.gridworld.actor.ActorWorld;
import info.gridworld.grid.Location;
import info.gridworld.grid.UnboundedGrid;

import java.awt.Color;

public class DancingBugRunner
{
	public static void main(String[] args)
	{
		UnboundedGrid grid = new UnboundedGrid<Actor>();
		ActorWorld world = new ActorWorld(grid);
		int[] turns =
				{ 1, 0, 0, 0, 1, 0, 0, 3, 4,
				  4, 0, 0, 1, 0, 3, 2, 0, 7,
				  0, 0, 0, 3, 2, 1  };
		DancingBug db = new DancingBug(turns);
		db.setColor(Color.ORANGE);
		world.add(new Location(9, 9), db);
		world.show();
	}
} 
