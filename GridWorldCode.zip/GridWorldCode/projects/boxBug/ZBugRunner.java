import info.gridworld.actor.ActorWorld;
import info.gridworld.grid.Location;

import java.awt.Color;

public class ZBugRunner
{
    public static void main(String[] args)
    {
        ActorWorld world = new ActorWorld();
        ZBug zb = new ZBug(4);
        world.add(new Location(4, 1), zb);
        world.show();
    }
}
