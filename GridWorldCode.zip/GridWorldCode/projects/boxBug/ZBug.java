import info.gridworld.actor.Bug;
import info.gridworld.grid.Location;

public class ZBug extends Bug
{
    private int steps;
    private int sideLength;
    private int side;

    public ZBug(int length)
    {
        setDirection(Location.EAST);
        steps = 0;
        sideLength = length;
        side = 1;
    }

    public void act()
    {
        if (steps < sideLength && side < sideLength)
        {
            move();
            steps++;
        }
        else
        {
            if (side == 1) {
                setDirection(Location.SOUTHWEST);
                side++;
                steps = 0;
            }
            else if (side == 2) {
                setDirection(Location.EAST);
                side++;
                steps = 0;
            }
        }
    }
}