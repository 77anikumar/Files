import info.gridworld.actor.Bug;

public class DancingBug extends Bug
{
    private int steps;
    private int[] danceTurns;

    public DancingBug(int[] turns)
    {
        steps = 0;
        danceTurns = turns;
    }

    public void turn(int count)
    {
        for (int i = 1; i <= count; i++)
            turn();
    }

    public void act()
    {
        if (steps == danceTurns.length)
            steps = 0;
        turn(danceTurns[steps]);
        steps++;
        super.act();
    }
}