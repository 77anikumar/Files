import info.gridworld.actor.Actor;
import info.gridworld.grid.UnboundedGrid;
import info.gridworld.actor.ActorWorld;
import info.gridworld.grid.Location;

import java.awt.Color;

public class CircleBugRunner
{
    public static void main(String[] args)
    {
        UnboundedGrid grid = new UnboundedGrid<Actor>();        
        ActorWorld world = new ActorWorld(grid);
        CircleBug cb1 = new CircleBug(3);
        world.add(new Location(5, 5), cb1);
        CircleBug cb2 = new CircleBug(8);
        cb2.setColor(Color.ORANGE);
        world.add(new Location(10, 10), cb2);
        world.show();
    }
}