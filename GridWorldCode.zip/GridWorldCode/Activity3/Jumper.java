import info.gridworld.grid.Grid;
import info.gridworld.grid.BoundedGrid;
import info.gridworld.grid.Location;
import info.gridworld.actor.ActorWorld;
import info.gridworld.actor.Actor;
import info.gridworld.actor.Bug;
import info.gridworld.actor.Rock;
import info.gridworld.actor.Flower;
import java.awt.Color;

public class Jumper extends Bug {
	private int counter = 0;
    private int jumpDistance;

    public Jumper() {
        setColor(Color.BLUE);
        this.jumpDistance = 4;
    }

    public Jumper(Color color, int jumpDistance) {
        setColor(color);
        this.jumpDistance = jumpDistance;
    }

    public void act() {
        if (canMove()){
            move();
            counter = 0;
        } else if (counter <= 5) {
            turn();
            counter++;
        } else if (canMoveOne()) {
            moveOne();
            counter = 0;
        } else {
            turn();
        }
    }

    /*public void act() {
        if (canMove()) {
            move();
            counter = 0;
        } else {
            int turns = 0;
            while (turns < 8 && !canMove()) {
                turn();
                turns++;
            }
            if (canMove()) {
                move();
                counter = 0;
            } else if (canMoveOne()) {
                moveOne();
                counter = 0;
            } else {
                turn();
            }
        }
    }*/

    public void turn() {
        setDirection(getDirection() + Location.HALF_RIGHT);
    }

    public void move() {
        Grid<Actor> ga = getGrid();
        if (ga == null)
            return;
        Location loc = getLocation();
        Location loc1 = loc.getAdjacentLocation(getDirection()); // one away
        Location loc2 = loc1.getAdjacentLocation(getDirection()); // two away
        if (ga.isValid(loc2))
            moveTo(loc2);
        else
            removeSelfFromGrid();
        Blossom blossom = new Blossom();
        blossom.putSelfInGrid(ga, loc);
    }

    public void moveOne() {
        Grid<Actor> ga = getGrid();
        if (ga == null)
            return;
        Location loc = getLocation();
        Location loc1 = loc.getAdjacentLocation(getDirection());
        if (ga.isValid(loc1))
            moveTo(loc1);
        else
            removeSelfFromGrid();
        Blossom blossom = new Blossom();
        blossom.putSelfInGrid(ga, loc);
    }

    public boolean canMoveOne() {
        Grid<Actor> ga = getGrid();
        if (ga == null)
            return false;
        Location loc = getLocation();
        Location loc1 = loc.getAdjacentLocation(getDirection());
        if (!ga.isValid(loc1))
            return false;
        Actor neighbor = ga.get(loc1);
        return (neighbor == null);
    }

    public boolean canMove() {
        Grid<Actor> ga = getGrid();
        if (ga == null)
            return false;
        Location loc = getLocation();
        Location loc1 = loc.getAdjacentLocation(getDirection());
        Location loc2 = loc1.getAdjacentLocation(getDirection());
        if (!ga.isValid(loc2))
            return false;
        Actor neighbor = ga.get(loc2);
        return (neighbor == null);
    }
}