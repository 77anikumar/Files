import info.gridworld.grid.Grid;
import info.gridworld.grid.BoundedGrid;
import info.gridworld.grid.Location;
import info.gridworld.actor.ActorWorld;
import info.gridworld.actor.Actor;
import info.gridworld.actor.Bug;
import info.gridworld.actor.Rock;
import info.gridworld.actor.Flower;
import java.awt.Color;

public class Jumper extends Bug {
    private int limit;
    private int currentMoves;

    public Jumper() {
        this.limit = 4;
        currentMoves = 0;
        setColor(Color.BLUE);
    }

    public Jumper(int limit) {
        this.limit = limit;
        currentMoves = 0;
        setColor(Color.BLUE);
    }

    public void act() {
        if (currentMoves == limit) {
            turn();
            currentMoves = 0;
        }
        if (canMove()) {
            move();
        } else {
            boolean foundMove = false;
            for (int i = 0; i < 8; i++) { // tries new directions
                turn();
                if (canMove()) {
                    move();
                    foundMove = true;
                    break;
                }
            }
            if (!foundMove && canMoveOne()) // if all cells two away are occupied
                moveOne();
        }
        currentMoves++;
    }

    public void move() {
        Grid<Actor> ga = getGrid();
        if (ga == null) return;
        Location loc = getLocation();
        Location loc1 = loc.getAdjacentLocation(getDirection()); // one away
        Location loc2 = loc1.getAdjacentLocation(getDirection()); // two away
        if (ga.isValid(loc2)) {
            moveTo(loc2);
            int randLifeTime = (int) (Math.random() * 10) + 15;
            new Blossom(randLifeTime).putSelfInGrid(ga, loc);
        } else
            turn();
    }

    public boolean canMove() {
        Grid<Actor> ga = getGrid();
        if (ga == null) return false;
        Location loc = getLocation();
        Location loc1 = loc.getAdjacentLocation(getDirection());
        Location loc2 = loc1.getAdjacentLocation(getDirection());
        if (!ga.isValid(loc2))
            return false;
        Actor neighbor = ga.get(loc2);
        return neighbor == null;
    }

    public void moveOne() {
        Grid<Actor> ga = getGrid();
        if (ga == null) return;
        Location loc = getLocation();
        Location loc1 = loc.getAdjacentLocation(getDirection());
        if (ga.isValid(loc1) && ga.get(loc1) == null) {
            moveTo(loc1);
            int randLifeTime = (int) (Math.random() * 10) + 15;
            new Blossom(randLifeTime).putSelfInGrid(ga, loc);
        }
    }

    public boolean canMoveOne() {
        Grid<Actor> ga = getGrid();
        if (ga == null) return false;
        Location loc = getLocation();
        Location loc1 = loc.getAdjacentLocation(getDirection());
        return ga.isValid(loc1) && ga.get(loc1) == null;
    }
}