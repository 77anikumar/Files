import info.gridworld.grid.Grid;
import info.gridworld.grid.BoundedGrid;
import info.gridworld.grid.Location;
import info.gridworld.actor.ActorWorld;
import info.gridworld.actor.Actor;
import info.gridworld.actor.Bug;
import info.gridworld.actor.Rock;
import info.gridworld.actor.Flower;
import java.awt.Color;

public class Jumper extends Bug {
    public Jumper() {
        setColor(Color.BLUE);
    }

    public void act() {
        if (canJump())
            jump();
        else if (canMove())
            move();
        else
            turn();
    }

    public boolean canJump() {
        Grid<Actor> ga = getGrid();
        if (ga == null)
            return false;
        Location loc = getLocation();
        Location next = loc.getAdjacentLocation(getDirection());
        Location finalLoc = next.getAdjacentLocation(getDirection());
        if (!ga.isValid(finalLoc))
            return false;
        Actor neighbor = ga.get(finalLoc);
        return ((neighbor == null) || (neighbor instanceof Blossom));
    }

    public void jump() {
        Grid<Actor> ga = getGrid();
        if (ga == null)
            return;
        Location loc = getLocation();
        Location loc1 = loc.getAdjacentLocation(getDirection()); // one away
        Location loc2 = loc1.getAdjacentLocation(getDirection()); // two away
        if (ga.isValid(loc2))
            moveTo(loc2);
        else
            removeSelfFromGrid();
        Blossom blossom = new Blossom();
        blossom.putSelfInGrid(ga, loc);
    }

    public boolean canMove() {
        Grid<Actor> ga = getGrid();
        if (ga == null)
            return false;
        Location loc = getLocation();
        Location loc1 = loc.getAdjacentLocation(getDirection());
        if (!ga.isValid(loc1))
            return false;
        Actor neighbor = ga.get(loc1);
        return ((neighbor == null) || (neighbor instanceof Blossom));
    }

    public void move() {
        Grid<Actor> ga = getGrid();
        if (ga == null)
            return;
        Location loc = getLocation();
        Location loc1 = loc.getAdjacentLocation(getDirection());
        if (ga.isValid(loc1))
            moveTo(loc1);
        else
            removeSelfFromGrid();
        Blossom blossom = new Blossom();
        blossom.putSelfInGrid(ga, loc);
    }
}