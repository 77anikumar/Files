import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;
import info.gridworld.actor.ActorWorld;
import info.gridworld.actor.Actor;
import info.gridworld.actor.Bug;
import info.gridworld.actor.Flower;
import java.awt.Color;

public class Blossom extends Flower {
    private static final Color DEFAULT_COLOR = Color.GREEN;
    private static final double DARKENING_FACTOR = 0.05;
    private int lifetime;

    public Blossom() {
        setColor(DEFAULT_COLOR);
        this.lifetime = 10;
    }

    public Blossom(int life) {
        setColor(DEFAULT_COLOR);
        this.lifetime = life;
    }

    public void act() {
        Color c = getColor();
        int red = (int) (c.getRed() * (1 - DARKENING_FACTOR));
        int green = (int) (c.getGreen() * (1 - DARKENING_FACTOR));
        int blue = (int) (c.getBlue() * (1 - DARKENING_FACTOR));
        setColor(new Color(red, green, blue));
        if (lifetime <= 0)
            removeSelfFromGrid();
        else
            lifetime--;
    }
}