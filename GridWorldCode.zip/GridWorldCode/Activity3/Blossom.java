import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;
import info.gridworld.actor.ActorWorld;
import info.gridworld.actor.Actor;
import info.gridworld.actor.Bug;
import info.gridworld.actor.Flower;
import java.awt.Color;

public class Blossom extends Flower {
    private static final double darken = 0.05;
    private int lifetime;

    public Blossom() {
        super(Color.GREEN);
        lifetime = 10;
    }

    public Blossom(int lifetime) {
        super(Color.GREEN);
        this.lifetime = lifetime;
    }

    public void act() {
        lifetime--;
        if (lifetime <= 0)
            removeSelfFromGrid();
        Color c = getColor();
        int red = (int) (c.getRed() * (1 - darken));
        int green = (int) (c.getGreen() * (1 - darken));
        int blue = (int) (c.getBlue() * (1 - darken));
        setColor(new Color(red, green, blue));
    }
}