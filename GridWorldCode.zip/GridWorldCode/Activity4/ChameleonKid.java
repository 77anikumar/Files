/**
 * A ChameleonKid changes its color to the color of one of the actors immediately
 * in front or behind. If there is no actor in either of these locations,
 * then the ChameleonKid darkens like the modified ChameleonCritter. 
 * 
 * @author  Ani Kumar
 * @since   March 19, 2025
 */

import info.gridworld.actor.Actor;
import info.gridworld.actor.Critter;
import info.gridworld.actor.Flower;
import info.gridworld.grid.Location;
import info.gridworld.grid.Grid;
import java.util.ArrayList;

public class ChameleonKid extends ChameleonCritter {

	/**
	 * Gets the actors to be processed. Returns the actors that are immediately in front
     * or behind of the critter. All actors must be in the same grid as the critter.
     * @return      list of actors that are near the critter
	 */
    public ArrayList<Actor> getActors() {
        ArrayList<Actor> actors = new ArrayList<>();
        int[] dirs = { Location.AHEAD, Location.HALF_CIRCLE };
        for (Location loc : getLocs(dirs)) {
            Actor actor = getGrid().get(loc);
            if (actor != null)
                actors.add(actor);
        }
        return actors;
    }

    /**
     * Finds and returns the valid adjacent locations of the critter.
     * 
     * @param dirs  array of directions to be checked
     * @return	    list of valid locations that are near the current location
     */
    public ArrayList<Location> getLocs(int[] dirs) {
        ArrayList<Location> locs = new ArrayList<>();
        Grid gr = getGrid();
        Location loc = getLocation();
        for (int dir : dirs) {
            Location nearbyLoc = loc.getAdjacentLocation(getDirection() + dir);
            if (gr.isValid(nearbyLoc))
                locs.add(nearbyLoc);
        }
        return locs;
    }
}