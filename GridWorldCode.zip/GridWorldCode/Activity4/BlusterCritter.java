/**
 * A BlusterCritter looks at all of the neighbors within two steps of its current
 * location.(For a BlusterCritter not near an edge, this includes 24 locations).
 * It counts the number of critters in those locations. If there are fewer than
 * c critters, the BlusterCritter’s color gets brighter (color values increase). If there
 * are c or more critters, the BlusterCritter’s color darkens (color values decrease)
 *
 * @author  Ani Kumar
 * @since   March 19, 2025
 */

import info.gridworld.actor.Actor;
import info.gridworld.actor.Rock;
import info.gridworld.actor.Critter;
import info.gridworld.grid.Location;
import java.util.ArrayList;
import java.awt.Color;

public class BlusterCritter extends Critter {
    private int courage;

    public BlusterCritter(int c) {
        super();
        courage = c;
    }

    /**
     * Gets the actors to be processed. Returns the actors that are in the
	 * locations within two steps of the critter. All actors must be in
	 * the same grid as the critter.
	 *
     * @return 			list of actors that are near the critter
     */
    public ArrayList<Actor> getActors() {
		ArrayList<Actor> actors = new ArrayList<>();
		Location loc = getLocation();
		for (int r = loc.getRow() - 2; r <= loc.getRow() + 2; r++) {
			for (int c = loc.getCol() - 2; c <= loc.getCol() + 2; c++) {
				Location temp = new Location(r, c);
				if (getGrid().isValid(temp)) {
					Actor actor = getGrid().get(temp);
					if (actor != null && actor != this)
						actors.add(actor);
				}
			}
		}
		return actors;
	}

	/**
	 * Processes the actors. Counts all the actors within two cells of the critter.
	 * If fewer than courage critters in these cells, the critter lightens. Else, it darkens.
	 * All actors must be in the same grid as the critter.
	 *
	 * @param actors	the actors that need to be processed
	 */
	public void processActors(ArrayList<Actor> actors) {
		int count = 0;
		for (Actor actor : actors) {
			if (actor instanceof Critter)
				count++;
		}
		if (count < courage)
			lighten();
		else
			darken();
	}

	/* Lightens the critter's color. */
	private void lighten() {
		Color c = getColor();
		int r = c.getRed();
		int g = c.getGreen();
		int b = c.getBlue();
		if (r < 255)
			r++;
		if (g < 255)
			g++;
		if (b < 255)
			b++;
		setColor(new Color(r, g, b));
	}

	/* Darkens the critter's color. */
	private void darken() {
		Color c = getColor();
		int r = c.getRed();
		int g = c.getGreen();
		int b = c.getBlue();
		if (r > 0)
			r--;
		if (g > 0)
			g--;
		if (b > 0)
			b--;
		setColor(new Color(r, g, b));
	}
}