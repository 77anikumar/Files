/**
 * A RockHound gets the actors to be processed in the same way as a Critter. It
 * removes any rocks in that list from the grid. A RockHound moves like a Critter.
 *
 * @author  Ani Kumar
 * @since   March 19, 2025
 */

import info.gridworld.actor.Actor;
import info.gridworld.actor.Rock;
import info.gridworld.actor.Critter;
import info.gridworld.grid.Location;
import java.util.ArrayList;

public class RockHound extends Critter {

    /**
     * Processes the actors and removes all the rocks around it.
     * All actors must be in the same grid as the critter.
     * @param actors    the actors that need to be processed
     */
    public void processActors(ArrayList<Actor> actors) {
        for (Actor actor : actors) {
            if (actor instanceof Rock)
                actor.removeSelfFromGrid();
        }
    }
}