/**
 * A QuickCrab processes actors the same way a CrabCritter does.
 * A QuickCrab moves to one of the two locations, randomly selected, that
 * are two spaces to its right or left, if that location and the intervening
 * location are both empty. Otherwise, a QuickCrab moves like a CrabCritter.
 *
 * @author  Ani Kumar
 * @since   March 19, 2025
 */

import info.gridworld.actor.Actor;
import info.gridworld.actor.Critter;
import info.gridworld.grid.Location;
import info.gridworld.grid.Grid;
import java.util.ArrayList;
import java.awt.Color;

public class QuickCrab extends CrabCritter {

	public QuickCrab() {
		setColor(Color.RED);
	}

	/**
	 * Gets the locations to move to.
	 * 
	 * @return			list of empty locations
	 */
	public ArrayList<Location> getMoveLocations() {
		ArrayList<Location> locs = new ArrayList<>();
		Grid gr = getGrid();
		locationTwoAway(locs,getDirection() + Location.LEFT);
		locationTwoAway(locs,getDirection() + Location.RIGHT);
		if (locs.isEmpty())
			return super.getMoveLocations();
		return locs;
	}

	/**
	 * Adds a location that is valid and two away (empty) in the direction that 
	 * direction specifies to the locs arrayList.
	 * 
	 * @param locs		list of valid locations
	 * @param direction	direction to check
	 */
	public void locationTwoAway(ArrayList<Location> validLocs, int direction) {
		Grid gr = getGrid();
		Location loc = getLocation();
		Location loc1 = loc.getAdjacentLocation(direction);
		Location loc2 = loc1.getAdjacentLocation(direction);
		if (gr.isValid(loc1) && gr.get(loc1) == null && // is one away empty?
			gr.isValid(loc2) && gr.get(loc2) == null)   // is two away empty?
			  validLocs.add(loc2);
	}
}
