/**
 * A KingCrab gets the actors to be processed in the same way a CrabCritter does.
 * A KingCrab causes each actor that it processes to move one location further
 * away from the KingCrab. If the actor cannot move away, the KingCrab removes
 * it from the grid. When the KingCrab has completed processing the actors,
 * it moves like a CrabCritter.
 *
 * @author  Ani Kumar
 * @since   March 19, 2025
 */

import info.gridworld.actor.Actor;
import info.gridworld.actor.Critter;
import info.gridworld.grid.Location;
import info.gridworld.grid.Grid;
import java.util.ArrayList;
import java.awt.Color;

public class KingCrab extends CrabCritter {

	public KingCrab() {
		setColor(Color.BLUE);
	}

	/**
	 * Calculates and rounds the integer distance between two given locations.
	 * 
	 * @param loc1		first location to compare
	 * @param loc2		second location to compare
	 * @return			the rounded distance between the two locations passed in
	 */
	public int distance(Location loc1, Location loc2) {
		int x1 = loc1.getRow();
		int y1 = loc1.getCol();
		int x2 = loc2.getRow();
		int y2 = loc2.getCol();
		double distance = Math.sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2)) + .5;
		return (int)Math.floor(distance);
	}

	/**
	 * Processess the actors passed in. Each actor moves one location
	 * radially away from KingCrab. If unable, actor is removed from grid.
	 * 
	 * @param actors	the list of actors to be processed
	 */
	public void processActors(ArrayList<Actor> actors) {
		for (Actor actor : actors)
			if (!moveAway(actor))
				actor.removeSelfFromGrid();
	}

	/**
	 * Returns true if actor can move to a location one away from
	 * KingCrab. Otherwise, returns false.
	 * 
	 * @param a			actor to be checked
	 * @return			if the actor can move away
	 */
	private boolean moveAway(Actor a) {
		ArrayList<Location> locs = getGrid().getEmptyAdjacentLocations(a.getLocation());
		for (Location loc : locs) {
			if (distance(getLocation(), loc) > 1) {
				a.moveTo(loc);
				return true;
			}
		}
		return false;
	}
}