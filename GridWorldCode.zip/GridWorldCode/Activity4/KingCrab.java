/**
 * A KingCrab gets the actors to be processed in the same way a CrabCritter does.
 * A KingCrab causes each actor that it processes to move one location further
 * away from the KingCrab. If the actor cannot move away, the KingCrab removes
 * it from the grid. When the KingCrab has completed processing the actors,
 * it moves like a CrabCritter.
 *
 * @author  Ani Kumar
 * @since   March 19, 2025
 */

import info.gridworld.actor.Actor;
import info.gridworld.actor.Critter;
import info.gridworld.grid.Location;
import info.gridworld.grid.Grid;
import java.util.ArrayList;
import java.awt.Color;

public class KingCrab extends CrabCritter {

	public KingCrab() {
		setColor(Color.RED);
	}

	/**
	 * Processess the actors passed in. Each actor moves one location
	 * radially away from KingCrab. If unable, actor is removed from grid.
	 * 
	 * @param actors	the list of actors to be processed
	 */
	public void processActors(ArrayList<Actor> actors) {
		Location loc = getLocation();
		Grid gr = getGrid();
		for (Actor actor : actors) {
			int direction = loc.getDirectionToward(actor.getLocation());
			Location loc1 = actor.getLocation().getAdjacentLocation(direction);
			if (!gr.isValid(loc1)) 	// unable to move, removed from grid
				actor.removeSelfFromGrid();
			else
				actor.moveTo(loc1); // actor moves
		}
	}
}
